taskset -c 40-47 /mnt/clathrin/alex-motioncorr-peakfit/build-cuda/cuda_peak_fit_float_denominator 
