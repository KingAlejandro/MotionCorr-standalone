
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     1.400000   300.000000     2.700000     0.100000     1.400000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographNameNoDW #1 
_rlnMicrographName #2 
_rlnMicrographMetadata #3 
_rlnOpticsGroup #4 
_rlnAccumMotionTotal #5 
_rlnAccumMotionEarly #6 
_rlnAccumMotionLate #7 
/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/matrix-cuda/save_nodw/out-float/Movies/mov00_g1_64x48x6_noDW.mrc /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/matrix-cuda/save_nodw/out-float/Movies/mov00_g1_64x48x6.mrc /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/matrix-cuda/save_nodw/out-float/Movies/mov00_g1_64x48x6.star            1    10.211629     3.504053     6.707576 
 
