#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-or-later
"""Recover one owned pre-native stalled controller without signaling a movie process."""
import json
import os
from pathlib import Path
import signal
import subprocess
import sys

w = Path.home() / 'mc-post-rc0-s1'
pid, curl_pid = 69721, 69744
root = Path('/tmp/mc-s1-3645672')
record = w / 'download-recovery-b4.json'
proc = Path('/proc') / str(pid)
expected = ['/usr/bin/python3', str(w / 'tools/scarf_campaign_v2.py'), '--families', 'e10474f4,e10164']
assert proc.stat().st_uid == os.getuid()
assert proc.joinpath('cmdline').read_bytes().decode().strip('\0').split('\0') == expected
if sys.argv[1] == 'finish':
    rec = json.loads(record.read_text())
    assert 'replacement_exit_status' in rec
    assert not (root / 'runs').exists()
    rec['original_controller_signals_after_replacement_finished'] = ['SIGTERM', 'SIGCONT']
    record.write_text(json.dumps(rec, indent=2) + '\n')
    os.kill(pid, signal.SIGTERM)
    os.kill(pid, signal.SIGCONT)
    raise SystemExit(0)
assert sys.argv[1] == 'run' and not record.exists()
os.kill(pid, signal.SIGSTOP)
try:
    assert not (root / 'runs').exists(), 'native movie work already started; refuse this recovery'
    curl = Path('/proc') / str(curl_pid)
    curl_args = curl.joinpath('cmdline').read_bytes().decode().strip('\0').split('\0')
    assert curl.stat().st_uid == os.getuid()
    assert curl_args[0] == 'curl' and str(root / 'data') in ' '.join(curl_args)
except BaseException:
    os.kill(pid, signal.SIGCONT)
    raise
try:
    os.kill(curl_pid, signal.SIGTERM)
except ProcessLookupError:
    pass
rec = dict(original_controller_pid=pid, original_argv=expected, stalled_download_pid=curl_pid,
           stalled_download_argv=curl_args, native_payloads_signaled=False,
           original_controller_had_no_native_runs=True, signals=['controller SIGSTOP', 'download SIGTERM'])
cmd = [sys.executable, str(w / 'tools/scarf_campaign_recover_v1.py'), '--families', 'e10474f4,e10164',
       '--cache-roots', '/tmp/mc-s1-3645672/data,/tmp/mc-s1-3645644/data']
rec['replacement_argv'] = cmd
record.write_text(json.dumps(rec, indent=2) + '\n')
r = subprocess.run(cmd, env=dict(os.environ, TMPDIR='/tmp'))
rec['replacement_exit_status'] = r.returncode
record.write_text(json.dumps(rec, indent=2) + '\n')
raise SystemExit(r.returncode)
