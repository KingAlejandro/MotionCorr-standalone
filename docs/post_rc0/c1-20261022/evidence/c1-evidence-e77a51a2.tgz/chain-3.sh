#!/bin/bash
# One-off orchestration (hash recorded): T24 with tools v2 (packet 772f2cf5; tested source e77a51a2), strictly sequential on CPUs 8-9 / GPU3.
export C1_SCR=/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb C1_SHA=e77a51a220cb0d91f4ac3c7fac211876d0c6833f
V=/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/tools-v2-run; PY=/home/alex/.mc-venv/bin/python3; F=/mnt/clathrin/alex-motioncorr-rc0/W-QF
cd /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb
until [ -f logs/chain-2.done ]; do sleep 10; done
st() { n=$1; shift; bash $V/c1_stage.sh $n "$@"; }
declare -A BIN=( [F-fresh]=$F/build-nvcomp/motioncorr [N]=$SC/attr/N/build/motioncorr [only254]=$SC/attr/only254/build/motioncorr [only260]=$SC/attr/only260/build/motioncorr [only270]=$SC/attr/only270/build/motioncorr [c1]=$SC/build-nvcomp/motioncorr )
for cfg in G L; do
  for a in F-fresh c1 N only254 only260 only270; do st t24-run-$a-$cfg $PY $V/c1_tutorial24.py run $a ${BIN[$a]} $cfg; done
  st t24-cmp-lane-$cfg $PY $V/c1_tutorial24.py compare $F/multigpu/$cfg/s0 $SC/t24/F-fresh-$cfg/out F-fresh_vs_F-retained-$cfg
  for a in c1 N only254 only260 only270; do st t24-cmp-F-$a-$cfg $PY $V/c1_tutorial24.py compare $SC/t24/F-fresh-$cfg/out $SC/t24/$a-$cfg/out F-fresh_vs_$a-$cfg; done
  for a in N only254 only260 only270; do st t24-cmp-$a-c1-$cfg $PY $V/c1_tutorial24.py compare $SC/t24/$a-$cfg/out $SC/t24/c1-$cfg/out ${a}_vs_c1-$cfg; done
  st t24-attribute-$cfg $PY $V/c1_tutorial24.py attribute $cfg
done
for cfg in G L; do st t24-dataset-c1-$cfg bash $V/c1_gpu_run.sh t24-ds-$cfg $PY $V/c1_tutorial24.py dataset c1 ${BIN[c1]} $cfg; done
for cfg in G L; do
  st t24-run-F-cpu-$cfg $PY $V/c1_tutorial24.py run F-cpu $F/build-cpu/motioncorr $cfg --cpu
  st t24-run-c1-cpu-$cfg $PY $V/c1_tutorial24.py run c1-cpu $SC/build-cpu/motioncorr $cfg --cpu
  st t24-cmp-cpu-$cfg $PY $V/c1_tutorial24.py compare $SC/t24/F-cpu-$cfg/out $SC/t24/c1-cpu-$cfg/out F-cpu_vs_c1-cpu-$cfg
done
echo chain-done > logs/chain-3.done
