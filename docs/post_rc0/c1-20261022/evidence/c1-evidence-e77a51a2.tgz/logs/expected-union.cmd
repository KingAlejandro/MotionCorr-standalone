taskset -c 8-9 /home/alex/.mc-venv/bin/python3 src/docs/post_rc0/c1-20261022/tools/c1_expected_union.py 
