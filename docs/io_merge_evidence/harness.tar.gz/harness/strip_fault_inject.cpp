// Test-only decoder-count injection; not production code or a benchmark.
#include <tiffio.h>
#include <dlfcn.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
static unsigned calls=0;
extern "C" tmsize_t TIFFReadEncodedStrip(TIFF *tif,uint32_t strip,void *buf,tmsize_t size) {
 using F=tmsize_t (*)(TIFF*,uint32_t,void*,tmsize_t);
 static F original=reinterpret_cast<F>(dlsym(RTLD_NEXT,"TIFFReadEncodedStrip"));
 tmsize_t actual=original(tif,strip,buf,size);
 const char *kind=std::getenv("MC_TEST_STRIP_FAULT");
 if(!kind || !std::strstr(TIFFFileName(tif),"strip_fault_fixture")) return actual;
 ++calls;
 tmsize_t changed=actual;
 if(!std::strcmp(kind,"zero") && calls==1) changed=0;
 if(!std::strcmp(kind,"positive_partial_row") && calls==1) changed=actual-1;
 if(!std::strcmp(kind,"oversize") && calls==1) changed=size+1;
 if(!std::strcmp(kind,"short_frame") && calls==3) changed=16;
 if(!std::strcmp(kind,"over_height") && calls==3) changed=64;
 std::fprintf(stderr,"[TEST_ONLY_STRIP] %s call=%u directory=%u strip=%u decoded=%ld returned=%ld requested=%ld\n",kind,calls,TIFFCurrentDirectory(tif),strip,(long)actual,(long)changed,(long)size);
 return changed;
}
