
# version 50001

data_general

_rlnImageSizeX                                       64
_rlnImageSizeY                                       48
_rlnImageSizeZ                                        6
_rlnMicrographMovieName                    Movies/mov00_g1_64x48x6.tiff
_rlnMicrographGainName                     gain.mrc
_rlnMicrographBinning                          2.000000
_rlnMicrographOriginalPixelSize                1.400000
_rlnMicrographDoseRate                         1.000000
_rlnMicrographPreExposure                      0.000000
_rlnVoltage                                  300.000000
_rlnMicrographStartFrame                              1
_rlnMotionModelVersion                                0
 

# version 50001

data_global_shift

loop_ 
_rlnMicrographFrameNumber #1 
_rlnMicrographShiftX #2 
_rlnMicrographShiftY #3 
           1     0.000000     0.000000 
           2     -0.92636     1.091507 
           3     -2.33410     2.594955 
           4     -3.68079     -0.20132 
           5     -5.11459     1.168314 
           6     -6.03754     2.489645 
 

# version 50001

data_hot_pixels

loop_ 
_rlnCoordinateX #1 
_rlnCoordinateY #2 
   34.000000    19.000000 
   35.000000    19.000000 
   33.000000    20.000000 
   34.000000    20.000000 
   35.000000    20.000000 
   36.000000    20.000000 
   37.000000    20.000000 
   32.000000    21.000000 
   33.000000    21.000000 
   34.000000    21.000000 
   35.000000    21.000000 
   36.000000    21.000000 
   37.000000    21.000000 
   32.000000    22.000000 
   33.000000    22.000000 
   34.000000    22.000000 
   35.000000    22.000000 
   36.000000    22.000000 
   37.000000    22.000000 
   32.000000    23.000000 
   33.000000    23.000000 
   34.000000    23.000000 
   35.000000    23.000000 
   36.000000    23.000000 
   37.000000    23.000000 
   33.000000    24.000000 
   34.000000    24.000000 
   35.000000    24.000000 
   36.000000    24.000000 
   34.000000    25.000000 
 
