
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     0.517000   300.000000     2.700000     0.100000     0.517000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographName #1 
_rlnMicrographMetadata #2 
_rlnOpticsGroup #3 
_rlnAccumMotionTotal #4 
_rlnAccumMotionEarly #5 
_rlnAccumMotionLate #6 
/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/c1-item12/runs/e10216-g1/out-ref_1db/Movies/FoilHole_14961495_Data_14966722_14966723_20180615_1739_Fractions.mrc /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/c1-item12/runs/e10216-g1/out-ref_1db/Movies/FoilHole_14961495_Data_14966722_14966723_20180615_1739_Fractions.star            1    69.018769    30.260684    38.758085 
/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/c1-item12/runs/e10216-g1/out-ref_1db/Movies/FoilHole_14961496_Data_14966722_14966723_20180615_1742_Fractions.mrc /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/c1-item12/runs/e10216-g1/out-ref_1db/Movies/FoilHole_14961496_Data_14966722_14966723_20180615_1742_Fractions.star            1  3234.400540   119.494486  3114.906055 
 
