
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     0.826000   300.000000     2.700000     0.100000     0.826000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographName #1 
_rlnMicrographMetadata #2 
_rlnOpticsGroup #3 
_rlnAccumMotionTotal #4 
_rlnAccumMotionEarly #5 
_rlnAccumMotionLate #6 
/mnt/clathrin/alex-motioncorr-s1/sweep/runs/e10361-00-p3-F-cuda/Movies/PS_18_2_4_CTEM_103-12_0007_Jan20_08_57_33.mrc /mnt/clathrin/alex-motioncorr-s1/sweep/runs/e10361-00-p3-F-cuda/Movies/PS_18_2_4_CTEM_103-12_0007_Jan20_08_57_33.star            1    25.146302     2.288052    22.858251 
 
