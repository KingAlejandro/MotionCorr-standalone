
# version 50001

data_general

_rlnImageSizeX                                       54
_rlnImageSizeY                                       72
_rlnImageSizeZ                                        8
_rlnMicrographMovieName                    Movies/mov00_g2_54x72x8.tiff
_rlnMicrographGainName                     gain.mrc
_rlnMicrographBinning                          1.000000
_rlnMicrographOriginalPixelSize                1.400000
_rlnMicrographDoseRate                         1.000000
_rlnMicrographPreExposure                      0.000000
_rlnVoltage                                  300.000000
_rlnMicrographStartFrame                              2
_rlnMotionModelVersion                                0
 

# version 50001

data_global_shift

loop_ 
_rlnMicrographFrameNumber #1 
_rlnMicrographShiftX #2 
_rlnMicrographShiftY #3 
           1  -9999.00000  -9999.00000 
           2     0.000000     0.000000 
           3     -0.95451     1.461375 
           4     -2.10832     -1.49525 
           5     -3.62750     0.022352 
           6     -5.18614     1.701058 
           7     -6.41411     -1.36194 
           8     -7.48869     0.117884 
 

# version 50001

data_hot_pixels

loop_ 
_rlnCoordinateX #1 
_rlnCoordinateY #2 
   30.000000    31.000000 
   31.000000    31.000000 
   32.000000    31.000000 
   29.000000    32.000000 
   30.000000    32.000000 
   31.000000    32.000000 
   32.000000    32.000000 
   33.000000    32.000000 
   28.000000    33.000000 
   29.000000    33.000000 
   30.000000    33.000000 
   31.000000    33.000000 
   32.000000    33.000000 
   33.000000    33.000000 
   34.000000    33.000000 
   28.000000    34.000000 
   29.000000    34.000000 
   30.000000    34.000000 
   31.000000    34.000000 
   32.000000    34.000000 
   33.000000    34.000000 
   34.000000    34.000000 
   28.000000    35.000000 
   29.000000    35.000000 
   30.000000    35.000000 
   31.000000    35.000000 
   32.000000    35.000000 
   33.000000    35.000000 
   34.000000    35.000000 
   29.000000    36.000000 
   30.000000    36.000000 
   31.000000    36.000000 
   32.000000    36.000000 
   33.000000    36.000000 
   30.000000    37.000000 
   31.000000    37.000000 
   32.000000    37.000000 
   33.000000    37.000000 
 
