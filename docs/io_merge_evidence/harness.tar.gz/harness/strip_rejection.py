#!/usr/bin/env python3
"""Targeted reader component checks with actual libtiff decode, altered return counts."""
import argparse,hashlib,importlib.util,json,os,re,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--dumper',type=Path,required=True);p.add_argument('--shim',type=Path,required=True);p.add_argument('--work',type=Path,required=True);p.add_argument('--json',type=Path,required=True);a=p.parse_args();a.work.mkdir(parents=True,exist_ok=True)
s=importlib.util.spec_from_file_location('writer',a.repo/'tests/test_tiff_read.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
fixture=a.work/'strip_fault_fixture.tif'
# Two frames, three strips per frame (4+4+2 rows); distinct ordered values.
frames=[[bytes((frame*31+row*7+x)%256 for x in range(16)) for row in range(10)] for frame in range(2)]
m.write_tiff(str(fixture),frames,8,1,4,16)
rows=[]
for kind in ('zero','positive_partial_row','oversize','short_frame','over_height'):
 out=a.work/(kind+'.bin');out.unlink(missing_ok=True)
 env=os.environ.copy();env.update(LD_PRELOAD=str(a.shim),MC_TEST_STRIP_FAULT=kind)
 cmd=[str(a.dumper),str(fixture),str(out)];r=subprocess.run(cmd,env=env,capture_output=True,text=True)
 calls=[int(n) for n in re.findall(r'call=(\d+)',r.stderr)]
 required='Invalid decoded TIFF strip size' if kind in ('zero','positive_partial_row','oversize') else ('do not fill the frame' if kind=='short_frame' else 'exceed the frame height')
 checks={'nonsignal_failure':0<r.returncode<128,'injected':bool(calls),'specific_rejection':required in r.stderr,'no_completed_dump':not out.exists(),'rejected_before_second_frame':bool(calls) and max(calls)<=3}
 rows.append({'kind':kind,'command':cmd,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'checks':checks,'pass':all(checks.values())})
r={'scope':'Targeted decoded-count component injection into libtiff return value; real valid encoded file. Not malformed-file or full pipeline injection. Ordinary multi-frame controls independently verify frame reset.','fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),'shim_sha256':hashlib.sha256(a.shim.read_bytes()).hexdigest(),'dumper_sha256':hashlib.sha256(a.dumper.read_bytes()).hexdigest(),'cases':rows,'pass':len(rows)==5 and all(v['pass'] for v in rows)}
a.json.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));raise SystemExit(0 if r['pass'] else 1)
