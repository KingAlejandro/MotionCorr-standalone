
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     0.517000   300.000000     2.700000     0.100000     0.517000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographNameNoDW #1 
_rlnMicrographName #2 
_rlnMicrographMetadata #3 
_rlnOpticsGroup #4 
_rlnAccumMotionTotal #5 
_rlnAccumMotionEarly #6 
_rlnAccumMotionLate #7 
/mnt/clathrin/alex-motioncorr-peakfit/runs/e10216-09-G-A1/Movies/FoilHole_17067881_Data_14966722_14966723_20180617_2252_Fractions_noDW.mrc /mnt/clathrin/alex-motioncorr-peakfit/runs/e10216-09-G-A1/Movies/FoilHole_17067881_Data_14966722_14966723_20180617_2252_Fractions.mrc /mnt/clathrin/alex-motioncorr-peakfit/runs/e10216-09-G-A1/Movies/FoilHole_17067881_Data_14966722_14966723_20180617_2252_Fractions.star            1    70.261097    30.281036    39.980061 
 
