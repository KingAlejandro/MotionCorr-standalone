
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     0.885000   200.000000     1.400000     0.100000     0.885000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographName #1 
_rlnMicrographMetadata #2 
_rlnOpticsGroup #3 
_rlnAccumMotionTotal #4 
_rlnAccumMotionEarly #5 
_rlnAccumMotionLate #6 
/scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00021_frameImage.mrc /scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00021_frameImage.star            1    16.409945     2.499242    13.910703 
/scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00022_frameImage.mrc /scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00022_frameImage.star            1    19.542675     2.473999    17.068676 
/scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00023_frameImage.mrc /scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00023_frameImage.star            1    17.541344     1.939181    15.602163 
/scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00024_frameImage.mrc /scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00024_frameImage.star            1    18.103183     1.722312    16.380871 
/scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00025_frameImage.mrc /scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00025_frameImage.star            1    24.119528     3.570279    20.549249 
/scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00026_frameImage.mrc /scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00026_frameImage.star            1    13.154425     1.827993    11.326432 
/scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00027_frameImage.mrc /scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00027_frameImage.star            1    15.081624     1.440508    13.641116 
/scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00028_frameImage.mrc /scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00028_frameImage.star            1    13.809481     1.112830    12.696651 
/scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00029_frameImage.mrc /scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00029_frameImage.star            1    16.182958     1.526964    14.655994 
/scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00030_frameImage.mrc /scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00030_frameImage.star            1    16.738708     1.881803    14.856905 
/scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00031_frameImage.mrc /scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00031_frameImage.star            1    13.605888     1.498053    12.107836 
/scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00035_frameImage.mrc /scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00035_frameImage.star            1    15.652134     1.687640    13.964494 
/scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00036_frameImage.mrc /scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00036_frameImage.star            1    12.969195     0.769496    12.199699 
/scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00037_frameImage.mrc /scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00037_frameImage.star            1    13.643192     1.395460    12.247732 
/scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00039_frameImage.mrc /scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00039_frameImage.star            1    12.163996     1.451719    10.712277 
/scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00040_frameImage.mrc /scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00040_frameImage.star            1    13.635976     1.239990    12.395986 
/scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00042_frameImage.mrc /scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00042_frameImage.star            1    15.115136     1.153147    13.961990 
/scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00043_frameImage.mrc /scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00043_frameImage.star            1    13.545284     1.360835    12.184449 
/scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00044_frameImage.mrc /scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00044_frameImage.star            1    15.234096     1.755923    13.478173 
/scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00045_frameImage.mrc /scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00045_frameImage.star            1    10.433727     1.101835     9.331891 
/scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00046_frameImage.mrc /scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00046_frameImage.star            1    11.555518     0.910882    10.644636 
/scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00047_frameImage.mrc /scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00047_frameImage.star            1    13.534635     0.793863    12.740772 
/scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00048_frameImage.mrc /scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00048_frameImage.star            1    12.212712     0.878544    11.334169 
/scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00049_frameImage.mrc /scratch/scarf1415/mc-io-merge-evidence/evidence-3510669/ab-standalone/out_standalone_j8/Movies/20170629_00049_frameImage.star            1    13.519428     1.433292    12.086136 
 
