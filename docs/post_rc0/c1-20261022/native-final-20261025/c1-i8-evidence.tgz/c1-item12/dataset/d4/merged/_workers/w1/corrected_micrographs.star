
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroupTut            1     0.885000   200.000000     1.400000     0.100000     0.885000 
opticsGroup10641            2     0.400000   300.000000     2.700000     0.100000     0.400000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographName #1 
_rlnMicrographMetadata #2 
_rlnOpticsGroup #3 
_rlnAccumMotionTotal #4 
_rlnAccumMotionEarly #5 
_rlnAccumMotionLate #6 
/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb-i8-20261025/c1-item12/dataset/d4/workers/w1/Movies/HM70-1_10-A-002_0002_Oct28_23_00_41.mrc /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb-i8-20261025/c1-item12/dataset/d4/workers/w1/Movies/HM70-1_10-A-002_0002_Oct28_23_00_41.star            2    81.185515    12.659731    68.525784 
 
