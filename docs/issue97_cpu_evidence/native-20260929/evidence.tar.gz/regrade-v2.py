import dataclasses,json,sys
from pathlib import Path
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
import compare_output_trees as c
sys.path.insert(0,str(R/'src/tests'))
import test_runner_contract as contract
stem='synthetic_128x128_8frames'
expected={stem+'.mrc',stem+'.star','corrected_micrographs.star'}
reports={}
for arm in ('off','on'):
    products={}
    for label in ('main','candidate'):
        root=R/('products-'+label)/arm
        files={p.name for p in root.iterdir() if p.suffix in ('.mrc','.star')}
        assert files==expected,(files,expected)
        log=(root/(stem+'.log')).read_text()
        assert log.count('[CUDA Patch Alignment] completed; converged=yes')==9
        assert '[CUDA Patch Alignment] completed; converged=no' not in log
        image=c.validate_mrc(root/(stem+'.mrc'),[128,128,1])
        rows=c._parse_joint_micrographs(root/'corrected_micrographs.star')
        assert len(rows)==1,rows
        assert rows[0][0]==arm+'/'+stem+'.mrc' and rows[0][1]==arm+'/'+stem+'.star',rows
        for name in (stem+'.star','corrected_micrographs.star'):
            assert c._parse_star_loops((root/name).read_text(),root/name)
        products[label]={'image':dataclasses.asdict(image),'stars':{n:(root/n).read_text() for n in (stem+'.star','corrected_micrographs.star')}}
    same_image=products['main']['image']==products['candidate']['image']
    same_stars=products['main']['stars']==products['candidate']['stars']
    if arm=='off': assert same_image and same_stars
    else: assert not same_image and not same_stars
    reports[arm]={'same_complete_image':same_image,'same_complete_stars':same_stars,'structural_inventory_pass':True,'image_provenance':{k:v['image'] for k,v in products.items()}}
on=contract.read_local_shifts(R/'products-main/on'/(stem+'.star'))
off=contract.read_local_shifts(R/'products-main/off'/(stem+'.star'))
assert len(on)==len(off)==9
failures=sum(on[p][3][a]!=off[p][3][a] for p in on for a in (0,1))
assert failures==18
report={'status':'PASS','old_source_anchor_failures':failures,'comparisons':reports,'scope':'One native selected-frame fixture, 9 converged CUDA patches per arm; intentional option-on difference; no science/performance claim','regrade_note':'Initial compare_trees invocation expected tutorial Movies/ layout; this fixture uses root-level products. Regraded retained products via identical structural validate_mrc and STAR parsers, exact declared inventory and timestamp-only header normalization.'}
(R/'regrade-v2.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
