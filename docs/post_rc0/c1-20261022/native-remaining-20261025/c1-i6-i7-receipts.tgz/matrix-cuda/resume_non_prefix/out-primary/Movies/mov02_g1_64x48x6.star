
# version 50001

data_general

_rlnImageSizeX                                       64
_rlnImageSizeY                                       48
_rlnImageSizeZ                                        6
_rlnMicrographMovieName                    Movies/mov02_g1_64x48x6.tiff
_rlnMicrographGainName                     gain.mrc
_rlnMicrographBinning                          1.000000
_rlnMicrographOriginalPixelSize                1.400000
_rlnMicrographDoseRate                         1.277000
_rlnMicrographPreExposure                      0.000000
_rlnVoltage                                  300.000000
_rlnMicrographStartFrame                              1
_rlnMotionModelVersion                                0
 

# version 50001

data_global_shift

loop_ 
_rlnMicrographFrameNumber #1 
_rlnMicrographShiftX #2 
_rlnMicrographShiftY #3 
           1     0.000000     0.000000 
           2     -0.93103     1.096491 
           3     -2.33221     2.614204 
           4     -3.67308     -0.17953 
           5     -5.10057     1.194689 
           6     -6.02797     2.531813 
 

# version 50001

data_hot_pixels

loop_ 
_rlnCoordinateX #1 
_rlnCoordinateY #2 
   34.000000    19.000000 
   35.000000    19.000000 
   33.000000    20.000000 
   34.000000    20.000000 
   35.000000    20.000000 
   36.000000    20.000000 
   37.000000    20.000000 
   32.000000    21.000000 
   33.000000    21.000000 
   34.000000    21.000000 
   35.000000    21.000000 
   36.000000    21.000000 
   37.000000    21.000000 
   32.000000    22.000000 
   33.000000    22.000000 
   34.000000    22.000000 
   35.000000    22.000000 
   36.000000    22.000000 
   37.000000    22.000000 
   32.000000    23.000000 
   33.000000    23.000000 
   34.000000    23.000000 
   35.000000    23.000000 
   36.000000    23.000000 
   37.000000    23.000000 
   33.000000    24.000000 
   34.000000    24.000000 
   35.000000    24.000000 
   36.000000    24.000000 
   34.000000    25.000000 
 
