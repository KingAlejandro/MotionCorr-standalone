
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     0.970000   300.000000     2.700000     0.100000     0.970000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographNameNoDW #1 
_rlnMicrographName #2 
_rlnMicrographMetadata #3 
_rlnOpticsGroup #4 
_rlnAccumMotionTotal #5 
_rlnAccumMotionEarly #6 
_rlnAccumMotionLate #7 
/mnt/clathrin/alex-motioncorr-peakfit/runs/e12963-02-G-cpu/Movies/FoilHole_4674724_Data_4659374_4659376_20230406_014450_EER_noDW.mrc /mnt/clathrin/alex-motioncorr-peakfit/runs/e12963-02-G-cpu/Movies/FoilHole_4674724_Data_4659374_4659376_20230406_014450_EER.mrc /mnt/clathrin/alex-motioncorr-peakfit/runs/e12963-02-G-cpu/Movies/FoilHole_4674724_Data_4659374_4659376_20230406_014450_EER.star            1    18.984976     2.654810    16.330166 
 
