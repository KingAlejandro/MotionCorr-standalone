#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-or-later
"""Hand off an owned controller after its current child finishes; never signal a payload."""
import fcntl
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

root = Path('/mnt/clathrin/alex-motioncorr-s1/sweep')
pid = 2009755
lock = (root / 'routing-control.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
record = root / 'acquisition/breadth-routing.json'
assert not record.exists()
proc = Path('/proc') / str(pid)
cmd = proc.joinpath('cmdline').read_bytes().decode().strip('\0').split('\0')
assert proc.stat().st_uid == os.getuid()
assert cmd[1:] == [str(root / 'tools/campaign.py'), '--root', str(root), '--all', '--wait-lock'], cmd
os.kill(pid, signal.SIGSTOP)
rec = dict(previous_pid=pid, previous_argv=cmd, native_payloads_signaled=False,
           rationale='same-venue family assignment: SCARF handles 10216/F3/10441/F4/10164; 4GPUs handles the rest',
           signals=[dict(pid=pid, signal='SIGSTOP')])
record.write_text(json.dumps(rec, indent=2) + '\n')
children = proc.joinpath('task', str(pid), 'children').read_text().split()
rec['children_allowed_to_finish'] = children
for child in children:
    p = Path('/proc') / child
    while p.exists():
        try:
            state = p.joinpath('stat').read_text().split(') ', 1)[1].split()[0]
        except FileNotFoundError:
            break
        if state == 'Z':
            break
        time.sleep(1)
os.kill(pid, signal.SIGTERM)
os.kill(pid, signal.SIGCONT)
rec['signals'] += [dict(pid=pid, signal='SIGTERM'), dict(pid=pid, signal='SIGCONT')]
record.write_text(json.dumps(rec, indent=2) + '\n')
while proc.exists():
    time.sleep(1)
for _ in range(20):
    if (root / 'breadth.exit').is_file():
        break
    time.sleep(1)
if (root / 'breadth.exit').is_file():
    rec['previous_controller_exit'] = (root / 'breadth.exit').read_text().strip()
if (root / 'breadth.log').exists():
    (root / 'breadth.log').rename(root / 'acquisition/breadth-before-routing.log')
manifest = json.loads((root / 'manifest.json').read_text())
# Finish both grids of the last touched movie, even if it is delegated afterwards.
last = max((root / 'runs').glob('*-F-*/run.json'), key=lambda p: p.stat().st_mtime)
movie = json.loads(last.read_text())['movie']
selection = root / 'acquisition/routing-finish-current.json'
selection.write_text(json.dumps(dict(movies=[r for r in manifest['movies'] if r['id'] == movie]), indent=2) + '\n')
rec['finish_current_movie'] = movie
rec['new_argv'] = [sys.executable, str(root / 'tools/campaign_routed_v1.py'), '--root', str(root), '--all',
                   '--exclude-families', 'e10216,e10474f3,e10441,e10474f4,e10164', '--wait-lock']
record.write_text(json.dumps(rec, indent=2) + '\n')
status = 1
try:
    first = [sys.executable, str(root / 'tools/campaign_routed_v1.py'), '--root', str(root), '--all',
             '--manifest', str(selection), '--wait-lock']
    with (root / 'breadth-routed.log').open('w') as log:
        subprocess.run(first, check=True, stdout=log, stderr=subprocess.STDOUT)
        subprocess.run(rec['new_argv'], check=True, stdout=log, stderr=subprocess.STDOUT)
    status = 0
finally:
    (root / 'breadth-routed.exit').write_text(str(status) + '\n')
