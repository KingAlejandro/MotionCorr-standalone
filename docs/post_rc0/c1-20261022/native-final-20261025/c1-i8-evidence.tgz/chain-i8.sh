#!/bin/bash
# C1 iteration i8 native chain (rows A13, K269/K272 CUDA, multi-device). Tested source e77a51a2; tools packet tools-v3-run (hashes in tools-v3-run.sha256).
# Launch: nohup setsid taskset -c 96-103 bash chain-i8.sh. Each stage is a c1_stage.sh stage (exclusive name, receipts); no stage is retried; a stage's exit does not stop the chain
# (contention/health stops are recorded in that stage's receipts and the next row is attempted); the review-gated ingest-poison phases are NOT part of this chain.
SC=/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb-i8-20261025
export C1_SCR=$SC C1_SHA=e77a51a220cb0d91f4ac3c7fac211876d0c6833f PYTHONDONTWRITEBYTECODE=1
T=$SC/tools-v3-run; source $T/c1_env.sh || exit 1
cd $SC
awk '/Cpus_allowed_list/{print $2}' /proc/self/status > logs/chain-i8.cpus
echo $$ > logs/chain-i8.pid; date -u +%FT%TZ > logs/chain-i8.started
[ "$(cat logs/chain-i8.cpus)" = 96-103 ] || { echo "chain not pinned to 96-103: $(cat logs/chain-i8.cpus)" > logs/chain-i8.stop; exit 1; }
S="bash $T/c1_stage.sh"
SYN=$SC/src/docs/post_rc0/s1/synth_combined; SCIPY=/mnt/clathrin/alex-motioncorr-synth-combined/venv/bin/python3
$S i8-a13 bash $T/c1_a13.sh
$S i8-census-cuda bash $T/c1_census_cuda.sh
$S i8-census-cmp taskset -c $C1_CPUS $C1_PY $T/c1_census.py compare results-c1-cuda $C1_KM_CUDA_REF cuda-none cuda $SC/census-cuda-vs-retained.json
$S i8-census-metrics taskset -c $C1_CPUS $C1_PY $T/c1_census.py metrics results-c1-cuda cuda $SC/census-cuda-metrics.json
$S i8-image-cuda taskset -c $C1_CPUS env OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 $SCIPY $SYN/image_batch.py eval $SC/census results-c1-cuda x 2
$S i8-image-controls taskset -c $C1_CPUS env OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 $SCIPY $SYN/image_batch.py controls $SC/census dose1-s00 $SC/i8-image-controls.json
$S i8-mg-item12 bash $T/c1_mg.sh i8-mg-item12 $C1_PY $T/c1_item12_mg.py --dataset
$S i8-mg-pub-GL bash $T/c1_mg.sh i8-mg-pub-GL $C1_PY $T/c1_mg_publication.py --configs G,L
$S i8-mg-pub-mixed bash $T/c1_mg.sh i8-mg-pub-mixed $C1_PY $T/c1_mg_publication.py --mixed
date -u +%FT%TZ > logs/chain-i8.finished; echo chain-done > logs/chain-i8.done
