#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-or-later
"""Replace owned login-side waiters before the next allocation is submitted."""
import json
import os
from pathlib import Path
import signal
import subprocess

w = Path.home() / 'mc-post-rc0-s1'
assert not (w / 'launch-a2/exit').exists()
assert not (w / 'launch-b3/job.id').exists()
assert not (w / 'routing-waiters.json').exists()
records = []
for pid, name in [(3482795, 'scarf_followon_v1.sh'), (3487374, 'scarf_prefetch_followon_v1.sh')]:
    p = Path('/proc') / str(pid)
    cmd = p.joinpath('cmdline').read_bytes().decode().strip('\0').split('\0')
    assert p.stat().st_uid == os.getuid()
    assert cmd == ['bash', str(w / 'tools' / name)], cmd
    records.append(dict(pid=pid, argv=cmd, signal='SIGTERM'))
for rec in records:
    os.kill(rec['pid'], signal.SIGTERM)
result = dict(native_payloads_signaled=False, stopped_waiters=records,
              rationale='assign 10641 and 12963 to 4GPUs; next SCARF allocation covers 10441/F4/10164')
(w / 'routing-waiters.json').write_text(json.dumps(result, indent=2) + '\n')
for name, tag in [('scarf_followon_v2.sh', 'followon-v2'), ('scarf_prefetch_followon_v2.sh', 'prefetch-b3-v2')]:
    with (w / (tag + '.out')).open('w') as log:
        p = subprocess.Popen(['bash', str(w / 'tools' / name)], stdin=subprocess.DEVNULL,
                             stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    (w / (tag + '.pid')).write_text(str(p.pid) + '\n')
print(json.dumps(result))
