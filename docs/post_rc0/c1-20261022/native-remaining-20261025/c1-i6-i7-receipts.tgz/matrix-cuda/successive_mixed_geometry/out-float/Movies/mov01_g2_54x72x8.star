
# version 50001

data_general

_rlnImageSizeX                                       54
_rlnImageSizeY                                       72
_rlnImageSizeZ                                        8
_rlnMicrographMovieName                    Movies/mov01_g2_54x72x8.tiff
_rlnMicrographBinning                          1.000000
_rlnMicrographOriginalPixelSize                1.400000
_rlnMicrographDoseRate                         1.000000
_rlnMicrographPreExposure                      0.000000
_rlnVoltage                                  300.000000
_rlnMicrographStartFrame                              1
_rlnMotionModelVersion                                0
 

# version 50001

data_global_shift

loop_ 
_rlnMicrographFrameNumber #1 
_rlnMicrographShiftX #2 
_rlnMicrographShiftY #3 
           1     0.000000     0.000000 
           2     -0.53104     1.110129 
           3     -1.72190     2.558939 
           4     -3.09542     -0.34850 
           5     -4.52988     1.107829 
           6     -5.91062     2.585319 
           7     -7.08553     -0.15527 
           8     -8.06999     1.125764 
 

# version 50001

data_hot_pixels

loop_ 
_rlnCoordinateX #1 
_rlnCoordinateY #2 
   30.000000    31.000000 
   31.000000    31.000000 
   32.000000    31.000000 
   29.000000    32.000000 
   30.000000    32.000000 
   31.000000    32.000000 
   32.000000    32.000000 
   33.000000    32.000000 
   28.000000    33.000000 
   29.000000    33.000000 
   30.000000    33.000000 
   31.000000    33.000000 
   32.000000    33.000000 
   33.000000    33.000000 
   28.000000    34.000000 
   29.000000    34.000000 
   30.000000    34.000000 
   31.000000    34.000000 
   32.000000    34.000000 
   33.000000    34.000000 
   28.000000    35.000000 
   29.000000    35.000000 
   30.000000    35.000000 
   31.000000    35.000000 
   32.000000    35.000000 
   33.000000    35.000000 
   28.000000    36.000000 
   29.000000    36.000000 
   30.000000    36.000000 
   31.000000    36.000000 
   32.000000    36.000000 
   33.000000    36.000000 
   30.000000    37.000000 
   31.000000    37.000000 
 
