
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     0.885000   200.000000     1.400000     0.100000     0.885000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographName #1 
_rlnMicrographMetadata #2 
_rlnOpticsGroup #3 
_rlnAccumMotionTotal #4 
_rlnAccumMotionEarly #5 
_rlnAccumMotionLate #6 
/home/ubuntu/mc-io-merge-evidence/damaged-combined/out_combined_truncated_partial_damaged_first_j4/Movies/DAMAGED_frameImage.mrc /home/ubuntu/mc-io-merge-evidence/damaged-combined/out_combined_truncated_partial_damaged_first_j4/Movies/DAMAGED_frameImage.star            1     6.432102     1.772215     4.659888 
/home/ubuntu/mc-io-merge-evidence/damaged-combined/out_combined_truncated_partial_damaged_first_j4/Movies/20170629_00021_frameImage.mrc /home/ubuntu/mc-io-merge-evidence/damaged-combined/out_combined_truncated_partial_damaged_first_j4/Movies/20170629_00021_frameImage.star            1    16.419638     2.504833    13.914805 
 
