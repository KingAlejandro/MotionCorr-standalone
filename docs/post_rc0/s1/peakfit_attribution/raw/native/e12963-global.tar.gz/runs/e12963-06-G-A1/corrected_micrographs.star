
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     0.970000   300.000000     2.700000     0.100000     0.970000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographNameNoDW #1 
_rlnMicrographName #2 
_rlnMicrographMetadata #3 
_rlnOpticsGroup #4 
_rlnAccumMotionTotal #5 
_rlnAccumMotionEarly #6 
_rlnAccumMotionLate #7 
/mnt/clathrin/alex-motioncorr-peakfit/runs/e12963-06-G-A1/Movies/FoilHole_4674814_Data_4659374_4659376_20230406_014703_EER_noDW.mrc /mnt/clathrin/alex-motioncorr-peakfit/runs/e12963-06-G-A1/Movies/FoilHole_4674814_Data_4659374_4659376_20230406_014703_EER.mrc /mnt/clathrin/alex-motioncorr-peakfit/runs/e12963-06-G-A1/Movies/FoilHole_4674814_Data_4659374_4659376_20230406_014703_EER.star            1    16.080573     1.627561    14.453012 
 
