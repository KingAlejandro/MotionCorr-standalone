
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     0.885000   300.000000     2.700000     0.100000     0.885000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographName #1 
_rlnMicrographMetadata #2 
_rlnOpticsGroup #3 
_rlnAccumMotionTotal #4 
_rlnAccumMotionEarly #5 
_rlnAccumMotionLate #6 
/private/tmp/motioncorr-b2-census-mac-20261027/replicate/runs/dose05-s00/FW/output/movie.mrc /private/tmp/motioncorr-b2-census-mac-20261027/replicate/runs/dose05-s00/FW/output/movie.star            1    15.798997     5.116195    10.682802 
 
