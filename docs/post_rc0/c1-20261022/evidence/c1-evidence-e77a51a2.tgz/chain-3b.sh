#!/bin/bash
# One-off orchestration, T24 iteration 2 (hash recorded). Tested source e77a51a2; tools packet d79f10f0 deployed at tools-v2.1-run. Sequential on CPUs 8-9 / GPU3.
SC=/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb
export C1_SCR=$SC C1_SHA=e77a51a220cb0d91f4ac3c7fac211876d0c6833f C1_T24_DIR=t24-i2
V=$SC/tools-v2.1-run; PY=/home/alex/.mc-venv/bin/python3; F=/mnt/clathrin/alex-motioncorr-rc0/W-QF; T=$SC/t24-i2
cd $SC
until [ -f logs/chain-3.done ]; do sleep 10; done
st() { n=$1; shift; bash $V/c1_stage.sh "$n" "$@"; }
declare -A BIN=( [F-fresh]=$F/build-nvcomp/motioncorr [N]=$SC/attr/N/build/motioncorr [only254]=$SC/attr/only254/build/motioncorr [only260]=$SC/attr/only260/build/motioncorr [only270]=$SC/attr/only270/build/motioncorr [c1]=$SC/build-nvcomp/motioncorr )
for cfg in G L; do
  for a in F-fresh c1 N only254 only260 only270; do st i2-run-$a-$cfg $PY $V/c1_tutorial24.py run $a ${BIN[$a]} $cfg; done
  st i2-cmp-lane-$cfg $PY $V/c1_tutorial24.py compare $F/multigpu/$cfg/s0 $T/F-fresh-$cfg/out F-fresh_vs_F-retained-$cfg
  for a in c1 N only254 only260 only270; do st i2-cmp-F-$a-$cfg $PY $V/c1_tutorial24.py compare $T/F-fresh-$cfg/out $T/$a-$cfg/out F-fresh_vs_$a-$cfg; done
  for a in N only254 only260 only270; do st i2-cmp-$a-c1-$cfg $PY $V/c1_tutorial24.py compare $T/$a-$cfg/out $T/c1-$cfg/out ${a}_vs_c1-$cfg; done
  st i2-attribute-$cfg $PY $V/c1_tutorial24.py attribute $cfg
done
for cfg in G L; do st i2-dataset-c1-$cfg bash $V/c1_gpu_run.sh i2-ds-$cfg $PY $V/c1_tutorial24.py dataset c1 ${BIN[c1]} $cfg; done
for cfg in G L; do
  base=$SC/t24/F-cpu-$cfg/out
  if ! grep -q '"rc": 0' $SC/t24/F-cpu-$cfg/RUN.json 2>/dev/null; then
    st i2-run-F-cpu-$cfg $PY $V/c1_tutorial24.py run F-cpu $F/build-cpu/motioncorr $cfg --cpu; base=$T/F-cpu-$cfg/out
  fi
  st i2-run-c1-cpu-$cfg $PY $V/c1_tutorial24.py run c1-cpu $SC/build-cpu/motioncorr $cfg --cpu
  st i2-cmp-cpu-$cfg $PY $V/c1_tutorial24.py compare $base $T/c1-cpu-$cfg/out F-cpu_vs_c1-cpu-$cfg
done
echo chain-done > logs/chain-3b.done
