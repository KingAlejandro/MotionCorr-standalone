
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     0.675000   300.000000     2.700000     0.100000     0.675000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographName #1 
_rlnMicrographMetadata #2 
_rlnOpticsGroup #3 
_rlnAccumMotionTotal #4 
_rlnAccumMotionEarly #5 
_rlnAccumMotionLate #6 
/mnt/clathrin/alex-motioncorr-s1/sweep/runs/e10164-00-p5-F-cuda/Movies/TS_01_000_0_0.mrc /mnt/clathrin/alex-motioncorr-s1/sweep/runs/e10164-00-p5-F-cuda/Movies/TS_01_000_0_0.star            1     2.305532     1.010457     1.295075 
 
