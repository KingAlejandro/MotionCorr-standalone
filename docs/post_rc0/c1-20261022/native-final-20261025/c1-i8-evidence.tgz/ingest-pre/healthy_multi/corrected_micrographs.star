
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     1.000000   300.000000     2.700000     0.100000     1.000000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographName #1 
_rlnMicrographMetadata #2 
_rlnOpticsGroup #3 
_rlnAccumMotionTotal #4 
_rlnAccumMotionEarly #5 
_rlnAccumMotionLate #6 
/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb-i8-20261025/ingest-pre/healthy_multi/Movies/control.mrc /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb-i8-20261025/ingest-pre/healthy_multi/Movies/control.star            1     9.423557     5.681719     3.741838 
/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb-i8-20261025/ingest-pre/healthy_multi/Movies/after1.mrc /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb-i8-20261025/ingest-pre/healthy_multi/Movies/after1.star            1     9.423557     5.681719     3.741838 
/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb-i8-20261025/ingest-pre/healthy_multi/Movies/after2.mrc /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb-i8-20261025/ingest-pre/healthy_multi/Movies/after2.star            1     9.423557     5.681719     3.741838 
 
