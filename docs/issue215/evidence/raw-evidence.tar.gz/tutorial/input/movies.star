data_optics

loop_
_rlnOpticsGroupName #1
_rlnOpticsGroup #2
_rlnMicrographOriginalPixelSize #3
_rlnVoltage #4
_rlnSphericalAberration #5
_rlnAmplitudeContrast #6
opticsGroup1 1 0.885 200 1.4 0.1

data_movies

loop_
_rlnMicrographMovieName #1
_rlnOpticsGroup #2
Movies/20170629_00026_frameImage.tiff 1
Movies/20170629_00031_frameImage.tiff 1
