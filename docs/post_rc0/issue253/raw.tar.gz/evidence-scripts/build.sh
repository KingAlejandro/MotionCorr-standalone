#!/bin/bash
set -euo pipefail
S=/mnt/clathrin/alex-motioncorr-253
export PATH=/home/alex/.mc-venv/bin:/usr/local/cuda-12.8/bin:$PATH
export CUDA_VISIBLE_DEVICES=GPU-b2cb2c39-8524-17fb-73a8-80cd61dbf83d
export CUDA_DEVICE_ORDER=PCI_BUS_ID OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1
export LD_LIBRARY_PATH=/usr/local/cuda-12.8/lib64:/home/alex/nvcomp53/nvcomp-linux-x86_64-5.3.0.16_cuda12-archive/lib
mkdir -p "$S/logs" "$S/src-main"
tar -xf "$S/main.tar" -C "$S/src-main"
# Test-only overlay on main: production bytes remain the archived main revision.
cp "$S/src-fix/tests/cuda_hermitian_inverse.cpp" "$S/src-main/tests/"
python3 - <<'PY'
from pathlib import Path
p=Path('/mnt/clathrin/alex-motioncorr-253/src-main/CMakeLists.txt')
s=p.read_text();s=s.replace('        # shift_retired: retired patches keep receiving phase shifts.', '''        add_executable(cuda_hermitian_inverse tests/cuda_hermitian_inverse.cpp)
        target_link_libraries(cuda_hermitian_inverse PRIVATE motioncorr_core)
        add_test(NAME CudaHermitianInverse COMMAND cuda_hermitian_inverse)
        # shift_retired: retired patches keep receiving phase shifts.''');p.write_text(s)
PY
build() {
 local name=$1 src=$2; shift 2
 taskset -c 88-95 cmake -S "$S/$src" -B "$S/build-$name" -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON -DPython3_EXECUTABLE=/home/alex/.mc-venv/bin/python3 "$@" > "$S/logs/configure-$name.log" 2>&1
 taskset -c 88-95 cmake --build "$S/build-$name" -j8 --target motioncorr cuda_hermitian_inverse > "$S/logs/build-$name.log" 2>&1
}
cu=(-DCUDA=ON -DCMAKE_CUDA_ARCHITECTURES=80 -DCMAKE_CUDA_COMPILER=/usr/local/cuda-12.8/bin/nvcc -DCUDAToolkit_ROOT=/usr/local/cuda-12.8)
build fix-nvcomp src-fix "${cu[@]}" -DUSE_NVCOMP=ON -DNVCOMP_ROOT=/home/alex/nvcomp53/nvcomp-linux-x86_64-5.3.0.16_cuda12-archive
set +e
taskset -c 88-95 "$S/build-fix-nvcomp/cuda_hermitian_inverse" --matrix > "$S/logs/inverse-fixed.log" 2>&1
echo $? > "$S/logs/inverse-fixed.exit"
set -e
build main-cuda src-main "${cu[@]}" -DUSE_NVCOMP=OFF
set +e
taskset -c 88-95 "$S/build-main-cuda/cuda_hermitian_inverse" > "$S/logs/inverse-main.log" 2>&1
echo $? > "$S/logs/inverse-main.exit"
set -e
echo done > "$S/build-stage.done"
