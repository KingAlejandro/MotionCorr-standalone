/mnt/clathrin/alex-motioncorr-guard264-20261022-3751bd05a954-cpu1/src-cand/docs/post_rc0/issue264/native/n3-cpu1/occupancy_cpu.sh cpu1-start 
