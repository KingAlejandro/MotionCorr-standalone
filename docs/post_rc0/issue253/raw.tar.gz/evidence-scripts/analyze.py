#!/usr/bin/env python3
import hashlib,importlib.util,json,pathlib,subprocess,sys
import numpy as np
S=pathlib.Path('/mnt/clathrin/alex-motioncorr-253')
spec=importlib.util.spec_from_file_location('cmp',S/'src-fix/tools/compare_motioncorr.py');cmp=importlib.util.module_from_spec(spec);spec.loader.exec_module(cmp)
P=S/'products'; A=S/'analysis';A.mkdir(exist_ok=True)
summary={}
def metrics(a,b):
 a=np.asarray(a,dtype=np.float64);b=np.asarray(b,dtype=np.float64);d=b-a
 rmse=float(np.sqrt(np.mean(d*d)));sigma=float(np.std(a));rms=float(np.sqrt(np.mean(a*a)))
 return dict(rmse=rmse,relative_rmse=rmse/max(sigma,1e-12),reference_std=sigma,relative_l2=rmse/max(rms,1e-12),max_abs=float(np.max(np.abs(d))))
def files(label):
 p=P/label/'Movies';star=next(p.glob('*.star'));mrc=next(x for x in p.glob('*.mrc') if not x.name.endswith('_noDW.mrc'))
 return star,mrc,mrc.with_name(mrc.stem+'_noDW.mrc')
def model(p):
 b=cmp.parse_star_file(p)
 for k,v in b.items():
  if 'local_motion_model' in k:
   labels=v['labels'];index=labels.index('_rlnMotionModelCoeff');idx=labels.index('_rlnMotionModelCoeffsIdx')
   values=np.zeros(36)
   for row in v['rows']:values[int(row[idx])]=float(row[index])
   return values.reshape(2,6,3)
 return None
def field(c):
 z=np.arange(59,dtype=np.float64)
 powers=np.array([z,z*z,z*z*z])
 x,y=np.meshgrid(np.linspace(-.5,.5,21),np.linspace(-.5,.5,21))
 spatial=np.array([np.ones_like(x),x,x*x,y,y*y,x*y]).reshape(6,-1)
 return np.einsum('asc,ct,sp->atp',c,powers,spatial)
for source in ['main','fixed']:
 for config in ['G','L']:
  refstar,refdw,refnd=files(f'{source}-cpu-{config}');teststar,testdw,testnd=files(f'{source}-cuda-{config}')
  rec={}
  for product,refmrc,testmrc in [('DW',refdw,testdw),('nonDW',refnd,testnd)]:
   out=A/f'{source}-{config}-{product}.json'
   argv=[sys.executable,str(S/'src-fix/tools/compare_motioncorr.py'),'--gate','backend','--ref-star',str(refstar),'--test-star',str(teststar),'--ref-mrc',str(refmrc),'--test-mrc',str(testmrc),'--ref-log',str(P/f'{source}-cpu-{config}'/'time.log'),'--test-log',str(P/f'{source}-cuda-{config}'/'time.log'),'--json-out',str(out)]
   r=subprocess.run(argv,capture_output=True,text=True);out.with_suffix('.log').write_text(r.stdout+r.stderr)
   data=json.loads(out.read_text());rec[product]=dict(exit_status=r.returncode,overall_status=data['overall_status'],image=data['checks']['corrected_image'])
   out.with_suffix('.command.json').write_text(json.dumps(argv,indent=2))
  a,b=model(refstar),model(teststar)
  if a is None or b is None:
   assert a is None and b is None and config=='G';rec['local_model']=None
  else:
   rec['local_model']=dict(serialized_coefficients=metrics(a,b),evaluated_field=metrics(field(a),field(b)),definition='Serialized STAR polynomial only; z=0..58, 21x21 grid including -0.5,+0.5 on each axis; relative RMSE = RMS(error)/population std(CPU field); relative L2 = RMS(error)/RMS(CPU field).')
  summary[f'{source}-{config}']=rec
for config in ['G','L']:
 a=files(f'main-cpu-{config}');b=files(f'fixed-cpu-{config}')
 rec={}
 for name,x,y in zip(['STAR','DW','nonDW'],a,b):
  if name=='STAR':
   rec[name]=dict(equal=cmp.parse_star_file(x)==cmp.parse_star_file(y),bytes_identical=x.read_bytes()==y.read_bytes())
  else:
   hx,px,ex=cmp.parse_mrc(x);hy,py,ey=cmp.parse_mrc(y)
   rec[name]=dict(core_header_identical=ex[:224]==ey[:224],labels_equal_after_date_normalization=cmp.normalized_mrc_labels(ex)==cmp.normalized_mrc_labels(ey),pixels_identical=px.tobytes()==py.tobytes(),metrics=metrics(px,py),sha256_pixels=hashlib.sha256(px.tobytes()).hexdigest())
 summary[f'CPU-control-{config}']=rec
(A/'products-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
