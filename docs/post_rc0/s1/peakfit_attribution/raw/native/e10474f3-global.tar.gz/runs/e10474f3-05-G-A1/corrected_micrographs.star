
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     1.060000   300.000000     2.700000     0.100000     1.060000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographNameNoDW #1 
_rlnMicrographName #2 
_rlnMicrographMetadata #3 
_rlnOpticsGroup #4 
_rlnAccumMotionTotal #5 
_rlnAccumMotionEarly #6 
_rlnAccumMotionLate #7 
/mnt/clathrin/alex-motioncorr-peakfit/runs/e10474f3-05-G-A1/Movies/2019-06-21_22-11-55_361_eer_data_4096x4096_noDW.mrc /mnt/clathrin/alex-motioncorr-peakfit/runs/e10474f3-05-G-A1/Movies/2019-06-21_22-11-55_361_eer_data_4096x4096.mrc /mnt/clathrin/alex-motioncorr-peakfit/runs/e10474f3-05-G-A1/Movies/2019-06-21_22-11-55_361_eer_data_4096x4096.star            1    13.775687     1.206155    12.569532 
 
