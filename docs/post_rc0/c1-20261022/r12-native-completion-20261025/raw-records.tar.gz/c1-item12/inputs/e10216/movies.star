# version 30001

data_optics

loop_
_rlnOpticsGroupName #1
_rlnOpticsGroup #2
_rlnMicrographOriginalPixelSize #3
_rlnVoltage #4
_rlnSphericalAberration #5
_rlnAmplitudeContrast #6
opticsGroup1 1 0.517 300 2.7 0.1

# version 30001

data_movies

loop_
_rlnMicrographMovieName #1
_rlnOpticsGroup #2
Movies/FoilHole_14961495_Data_14966722_14966723_20180615_1739_Fractions.mrcs 1
Movies/FoilHole_14961496_Data_14966722_14966723_20180615_1742_Fractions.mrcs 1
