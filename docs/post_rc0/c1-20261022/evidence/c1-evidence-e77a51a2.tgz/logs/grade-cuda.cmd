/home/alex/.mc-venv/bin/python3 /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/src/docs/post_rc0/c1-20261022/tools/c1_grade_ctest.py cuda 
