
# version 50001

data_general

_rlnImageSizeX                                      512
_rlnImageSizeY                                      384
_rlnImageSizeZ                                        5
_rlnMicrographMovieName                    movie.mrcs
_rlnMicrographBinning                          1.000000
_rlnMicrographOriginalPixelSize                0.885000
_rlnMicrographDoseRate                         1.000000
_rlnMicrographPreExposure                      0.000000
_rlnVoltage                                  300.000000
_rlnMicrographStartFrame                              1
_rlnMotionModelVersion                                0
 

# version 50001

data_global_shift

loop_ 
_rlnMicrographFrameNumber #1 
_rlnMicrographShiftX #2 
_rlnMicrographShiftY #3 
           1     0.000000     0.000000 
           2     -0.99454     2.012734 
           3     -2.01237     4.037640 
           4     -3.03400     6.065642 
           5     -4.03750     8.088424 
 
