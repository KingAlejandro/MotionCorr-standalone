
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     0.826000   300.000000     2.700000     0.100000     0.826000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographName #1 
_rlnMicrographMetadata #2 
_rlnOpticsGroup #3 
_rlnAccumMotionTotal #4 
_rlnAccumMotionEarly #5 
_rlnAccumMotionLate #6 
/mnt/clathrin/alex-motioncorr-s1/sweep/runs/e10361-01-p5-F-cpu/Movies/PS_18_2_4_CTEM_103-18_0004_Jan20_09_12_45.mrc /mnt/clathrin/alex-motioncorr-s1/sweep/runs/e10361-01-p5-F-cpu/Movies/PS_18_2_4_CTEM_103-18_0004_Jan20_09_12_45.star            1    21.607025     1.326217    20.280808 
 
