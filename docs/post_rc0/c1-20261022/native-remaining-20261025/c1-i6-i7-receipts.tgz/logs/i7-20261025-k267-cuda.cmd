bash /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/tools-v2.4-run/c1_v2.sh cuda 
