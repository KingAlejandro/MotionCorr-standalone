taskset -c 40-47 ctest --test-dir /mnt/clathrin/alex-motioncorr-peakfit/build-cpu --output-on-failure --output-junit /mnt/clathrin/alex-motioncorr-peakfit/logs/ctest-cpu-git.xml -j1 
