#!/bin/bash
# SPDX-License-Identifier: GPL-2.0-or-later
set -u
W=$HOME/mc-post-rc0-s1
while [ ! -f "$W/launch-b3/job.id" ]; do
  if [ -f "$W/launch-b3/exit" ]; then cat "$W/launch-b3/exit" > "$W/prefetch-b3.exit"; exit 1; fi
  sleep 15
done
job=$(cat "$W/launch-b3/job.id")
srun --jobid="$job" --overlap --cpus-per-task=8 bash -c 'export TMPDIR=/tmp; W=$HOME/mc-post-rc0-s1; root=/tmp/mc-s1-$SLURM_JOB_ID; until [ -d "$root/acquisition" ]; do sleep 1; done; exec /usr/bin/python3 "$W/tools/scarf_prefetch_v1.py" --root "$root" --families e10641,e12963,e10441,e10474f4,e10164' > "$W/prefetch-b3.log" 2>&1
rc=$?
echo "$rc" > "$W/prefetch-b3.exit"
exit "$rc"
