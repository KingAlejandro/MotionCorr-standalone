#!/bin/bash
set -u
S=/mnt/clathrin/alex-motioncorr-peakfit
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1 LD_LIBRARY_PATH=/usr/local/cuda-12.8/lib64:/home/alex/nvcomp53/nvcomp-linux-x86_64-5.3.0.16_cuda12-archive/lib
P=/mnt/clathrin/alex-motioncorr-s1ccf/build-prod-cpu/motioncorr
F=$S/build-cpu/motioncorr
mkdir -p $S/tier-A-control/{parent,fixed}
sha256sum $P $F > $S/logs/tier-A-control-binaries.sha256
cd $S/src-fix/test-data/fixtures
for arm in parent fixed; do
 bin=$F;[ $arm = parent ] && bin=$P
 taskset -c 48-55 $bin --i synthetic_128x128_8frames.star --o $S/tier-A-control/$arm --use_own --j 1 > $S/logs/tier-A-control-$arm.log 2>&1
 echo $? > $S/logs/tier-A-control-$arm.exit
done
taskset -c 48-55 /home/alex/.mc-venv/bin/python3 $S/src-fix/tools/compare_motioncorr.py --ref $S/tier-A-control/parent --test $S/tier-A-control/fixed --gate exact --require-complete-coverage --json-out $S/logs/tier-A-parent-vs-fixed.json > $S/logs/tier-A-parent-vs-fixed.log 2>&1
echo $? > $S/logs/tier-A-parent-vs-fixed.exit
