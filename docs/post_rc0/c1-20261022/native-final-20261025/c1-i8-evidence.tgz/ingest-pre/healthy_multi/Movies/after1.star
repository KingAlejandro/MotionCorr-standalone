
# version 50001

data_general

_rlnImageSizeX                                       48
_rlnImageSizeY                                       40
_rlnImageSizeZ                                        6
_rlnMicrographMovieName                    Movies/after1.tiff
_rlnMicrographBinning                          1.000000
_rlnMicrographOriginalPixelSize                1.000000
_rlnMicrographDoseRate                         1.000000
_rlnMicrographPreExposure                      0.000000
_rlnVoltage                                  300.000000
_rlnMicrographStartFrame                              1
_rlnMotionModelVersion                                0
 

# version 50001

data_global_shift

loop_ 
_rlnMicrographFrameNumber #1 
_rlnMicrographShiftX #2 
_rlnMicrographShiftY #3 
           1     0.000000     0.000000 
           2     -1.28095     1.365468 
           3     -2.36196     -0.00212 
           4     -3.80928     1.472518 
           5     -4.84049     0.024878 
           6     -6.29283     1.347689 
 

# version 50001

data_hot_pixels

loop_ 
_rlnCoordinateX #1 
_rlnCoordinateY #2 
   26.000000    18.000000 
   27.000000    18.000000 
   28.000000    18.000000 
   29.000000    18.000000 
   24.000000    19.000000 
   25.000000    19.000000 
   26.000000    19.000000 
   27.000000    19.000000 
   28.000000    19.000000 
 
