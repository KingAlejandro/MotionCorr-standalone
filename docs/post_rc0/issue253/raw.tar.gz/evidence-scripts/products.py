#!/usr/bin/env python3
import csv,hashlib,json,os,pathlib,subprocess,time
S=pathlib.Path('/mnt/clathrin/alex-motioncorr-253')
inputs=pathlib.Path('/mnt/clathrin/alex-motioncorr-s1ccf/inputs/e10216')
uuid='GPU-b2cb2c39-8524-17fb-73a8-80cd61dbf83d'
env=dict(os.environ,OMP_NUM_THREADS='8',OPENBLAS_NUM_THREADS='1',CUDA_VISIBLE_DEVICES=uuid,CUDA_DEVICE_ORDER='PCI_BUS_ID',LD_LIBRARY_PATH='/usr/local/cuda-12.8/lib64:/home/alex/nvcomp53/nvcomp-linux-x86_64-5.3.0.16_cuda12-archive/lib')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
(S/'products').mkdir(exist_ok=True)
movie=next((inputs/'Movies').glob('*1739*'))
(S/'products/input.json').write_text(json.dumps(dict(path=str(movie),resolved=str(movie.resolve()),sha256=sha(movie),star=(inputs/'movies.star').read_text()),indent=2))
for source,backend,binary in [('main','cpu','build-main-cuda'),('main','cuda','build-main-cuda'),('fixed','cpu','build-fix-cpu'),('fixed','cuda','build-fix-cuda')]:
 for config in ['G','L']:
  name=f'{source}-{backend}-{config}'; out=S/'products'/name;out.mkdir(exist_ok=True)
  args=['--use_own','--dose_weighting','--save_noDW','--bfactor','150','--seed','1','--dose_per_frame','1.0','--expected_frames','59','--j','8','--i','movies.star','--o',str(out)+'/', '--ingest_witness',str(out/'witness.txt')]
  if config=='L':args+=['--patch_x','5','--patch_y','5']
  if backend=='cuda':args+=['--gpu','0','--ingest','auto']
  cmd=['/usr/bin/time','-v','taskset','-c','88-95',str(S/binary/'motioncorr')]+args
  record=dict(argv=cmd,cwd=str(inputs),binary_sha256=sha(S/binary/'motioncorr'),cpu_mask='88-95',gpu_uuid=uuid if backend=='cuda' else None,actual_cpu_affinity=sorted(os.sched_getaffinity(0)),started=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
  (out/'command.json').write_text(json.dumps(record,indent=2))
  with (out/'stdout.log').open('w') as stdout,(out/'time.log').open('w') as stderr,(out/'gpu-samples.csv').open('w') as samples:
   p=subprocess.Popen(cmd,cwd=inputs,env=env,stdout=stdout,stderr=stderr)
   record['time_pid']=p.pid; observed=set(); own_pids=set()
   while p.poll() is None:
    if backend=='cuda':
     children=pathlib.Path(f'/proc/{p.pid}/task/{p.pid}/children')
     try: own_pids.update(int(x) for x in children.read_text().split())
     except FileNotFoundError: pass
     q=subprocess.run(['nvidia-smi','--query-compute-apps=pid,gpu_uuid,process_name,used_memory','--format=csv,noheader'],capture_output=True,text=True)
     for row in csv.reader(q.stdout.splitlines()):
      if len(row)==4 and row[0].strip().isdigit() and int(row[0]) in own_pids: observed.add(row[1].strip())
     samples.write(time.strftime('%FT%TZ',time.gmtime())+'\n'+q.stdout);samples.flush()
    time.sleep(1)
   record.update(gpu_observed_uuids=sorted(observed),sampled_child_pids=sorted(own_pids),exit_status=p.returncode,finished=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
  (out/'command.json').write_text(json.dumps(record,indent=2));print(name,p.returncode,flush=True)
  if p.returncode:raise SystemExit(p.returncode)
  if backend=='cuda' and observed!={uuid}:raise SystemExit(f'{name}: GPU witness failed: {observed}')
(S/'products-stage.done').write_text('done\n')
