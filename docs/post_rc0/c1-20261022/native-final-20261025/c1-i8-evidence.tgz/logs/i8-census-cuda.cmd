bash /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb-i8-20261025/tools-v3-run/c1_census_cuda.sh 
