#!/bin/bash
echo CHAIN_RAN > /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/cpu1d-startup-controls-attempt1/foreign-chain-ran
