taskset -c 8-9 nice -n 19 /home/alex/.mc-venv/bin/python3 -B tools-v2.3-run/test_c1_t24_failclosed.py -v 
