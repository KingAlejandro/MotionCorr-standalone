
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     0.885000   200.000000     1.400000     0.100000     0.885000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographName #1 
_rlnMicrographMetadata #2 
_rlnOpticsGroup #3 
_rlnAccumMotionTotal #4 
_rlnAccumMotionEarly #5 
_rlnAccumMotionLate #6 
/mnt/clathrin/alex-motioncorr-215/tutorial/G-fixed/Movies/20170629_00026_frameImage.mrc /mnt/clathrin/alex-motioncorr-215/tutorial/G-fixed/Movies/20170629_00026_frameImage.star            1    13.154425     1.827993    11.326432 
/mnt/clathrin/alex-motioncorr-215/tutorial/G-fixed/Movies/20170629_00031_frameImage.mrc /mnt/clathrin/alex-motioncorr-215/tutorial/G-fixed/Movies/20170629_00031_frameImage.star            1    13.605888     1.498053    12.107836 
 
