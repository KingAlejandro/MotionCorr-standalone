#!/usr/bin/env python3
"""Iteration-3 pre-launch validation (read-only). Writes i3-prelaunch-validation.json in the scratch; exit 0 only if every check passes."""
import hashlib, json, os, re, shutil, subprocess, sys
from pathlib import Path
SC = Path('/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb'); SHA = 'e77a51a220cb0d91f4ac3c7fac211876d0c6833f'
F = Path('/mnt/clathrin/alex-motioncorr-rc0/W-QF'); DATA = Path('/home/alex/motioncorr-validation-20261011-vm/tutorial-data')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
res, bad = {}, []
def check(name, ok, detail=None):
    res[name] = {'ok': bool(ok), 'detail': detail}
    if not ok: bad.append(name)
g = lambda *a: subprocess.run(['git', '-C', str(SC / 'src'), *a], capture_output=True, text=True).stdout.strip()
check('source_head', g('rev-parse', 'HEAD') == SHA, g('rev-parse', 'HEAD'))
check('source_clean', g('status', '--porcelain') == '', g('status', '--porcelain')[:200])
r = subprocess.run(['sha256sum', '-c', 'source.tar.sha256'], cwd=SC, capture_output=True, text=True); check('source_archive_hash', r.returncode == 0, r.stdout.strip())
# deployed tools vs the packet 4facd76d expectation (computed locally from git and copied here)
exp = dict(l.split()[::-1] for l in (SC / 'boot-tools/expected-tools-4facd76d.txt').read_text().splitlines())
dep = {p.name: sha(p) for p in (SC / 'tools-v2.3-run').iterdir() if p.is_file() and not p.name.endswith(('.sha256', '.PROVENANCE'))}
diff = sorted(k for k in set(exp) | set(dep) if exp.get(k) != dep.get(k))
check('deployed_tools_equal_packet_4facd76d', not diff, {'files': len(dep), 'differing': diff})
log = (SC / 'logs/overlay-suite-4facd76d.log').read_text()
check('linux_suite_receipt', (SC / 'logs/overlay-suite-4facd76d.exit').read_text().strip() == '0' and 'Ran 24 tests' in log and re.search(r'^OK$', log, re.M) and 'skipped' not in log.lower(),
      {'exit': (SC / 'logs/overlay-suite-4facd76d.exit').read_text().strip(), 'ran': re.findall(r'Ran \d+ tests', log)})
fcpu = sha(F / 'build-cpu/motioncorr')
for c in 'GL':
    j = json.loads((SC / f't24/F-cpu-{c}/RUN.json').read_text())
    check(f'cpu_baseline_{c}', j['rc'] == 0 and j['binary_sha256'] == fcpu and not j['gpu_run'] and '--ingest' not in j['args'], {'rc': j['rc'], 'bin': j['binary_sha256'][:16], 'wall_s': j.get('wall_s')})
star = (DATA / 'movies.star').read_text(); rows = re.findall(r'^(Movies/\S+)\s', star, flags=re.M)
for c in 'GL':
    m = json.loads((F / f'multigpu/{c}/manifest.json').read_text())
    check(f'manifest_{c}_24_movies_order_hash', rows == m['movies'] and len(rows) == 24 and len(set(rows)) == 24 and sha(DATA / 'movies.star') == m['input_star_sha256'],
          {'rows': len(rows), 'order_equal': rows == m['movies'], 'star_sha': sha(DATA / 'movies.star')[:16], 'manifest_sha': sha(F / f'multigpu/{c}/manifest.json')[:16]})
prov = {}
for c in 'GL':
    jp = F / f'multigpu/{c}/cmp-w1_vs_s0-products.json'; j = json.loads(jp.read_text()); m = json.loads((F / f'multigpu/{c}/manifest.json').read_text())
    stars = sorted(p for p in (F / f'multigpu/{c}/s0').rglob('*.star'))
    same = all(all(v[f'base_{k}'] == v[f'candidate_{k}'] for k in ('header', 'extended', 'payload')) for v in j['mrc_sha256'].values())
    check(f'retained_report_{c}', j['status'] == 'PASS' and j['comparison_scope'] == 'products' and len(j['mrc_sha256']) == 24 and not j['different_products'] and same and len(stars) == 25
          and j['base']['star_count'] == 25 and j['base']['movie_count'] == 24, {'sha256': sha(jp), 'mtime': os.path.getmtime(jp), 'base_root': j['base'].get('root'), 'candidate_root': j['candidate'].get('root'), 'stars_in_s0': len(stars)})
    prov[c] = {'comparison_report': str(jp), 'comparison_report_sha256': sha(jp), 'manifest_sha256': sha(F / f'multigpu/{c}/manifest.json'),
               'retained_star_sha256': {str(p.relative_to(F / f'multigpu/{c}/s0')): sha(p) for p in stars}, 'mrc_images_present_in_retained_tree': len(list((F / f'multigpu/{c}/s0').rglob('*.mrc')))}
(SC / 'retained-baseline-provenance.json').write_text(json.dumps(prov, indent=1) + '\n')
# A1 prerequisites
bins = {'cuda': SC / 'build-cuda/motioncorr', 'nvcomp': SC / 'build-nvcomp/motioncorr'}
check('a1_binaries', all(p.is_file() for p in bins.values()), {k: sha(p) for k, p in bins.items()})
pb = Path('/mnt/clathrin/alex-motioncorr-214/tools/usr/bin/pbzip2')
check('a1_decoders', sha(pb) == '35410d199baebff55262e43cac9e8cdf9d14b540143c8e70ee53c6cf8ca9f21e' and shutil.which('xz') and shutil.which('zstd'), {'pbzip2': sha(pb)[:16], 'xz': shutil.which('xz'), 'zstd': shutil.which('zstd')})
check('a1_driver_files', all((SC / 'src/tests' / n).is_file() for n in ('test_compressed_mrc_status.py', 'test_truncated_mrc_movie.py')), {n: sha(SC / 'src/tests' / n)[:16] for n in ('test_compressed_mrc_status.py', 'test_truncated_mrc_movie.py')})
check('a1_work_dirs_fresh', not (SC / 'a249').exists(), str(SC / 'a249'))
check('iteration3_names_fresh', not list((SC / 'logs').glob('i3-*')) and not (SC / 't24-i3').exists(), None)
out = {'checks': res, 'failed': bad, 'tested_source': SHA}
(SC / 'i3-prelaunch-validation.json').write_text(json.dumps(out, indent=1, default=str) + '\n')
for k, v in res.items(): print('PASS' if v['ok'] else 'FAIL', k)
sys.exit(1 if bad else 0)
