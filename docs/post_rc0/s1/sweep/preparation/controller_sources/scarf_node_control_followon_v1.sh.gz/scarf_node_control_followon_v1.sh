#!/bin/bash
# SPDX-License-Identifier: GPL-2.0-or-later
set -u
W=$HOME/mc-post-rc0-s1
while [ ! -f "$W/launch-b3/job.id" ]; do sleep 15; done
job=$(cat "$W/launch-b3/job.id")
srun --jobid="$job" --overlap --cpus-per-task=8 bash -c 'export TMPDIR=/tmp; root=/tmp/mc-s1-$SLURM_JOB_ID; until [ -f "$root/lane.json" ]; do sleep 1; done; exec /usr/bin/python3 "$HOME/mc-post-rc0-s1/tools/scarf_node_control_v1.py"' > "$W/node-control-b3.log" 2>&1
rc=$?
echo "$rc" > "$W/node-control-b3.exit"
exit "$rc"
