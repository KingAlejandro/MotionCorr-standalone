
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     1.060000   300.000000     2.700000     0.100000     1.060000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographName #1 
_rlnMicrographMetadata #2 
_rlnOpticsGroup #3 
_rlnAccumMotionTotal #4 
_rlnAccumMotionEarly #5 
_rlnAccumMotionLate #6 
/tmp/s13n-3646484/runs/e10474f3-07-p3-on/Movies/2019-06-22_01-14-22_808_eer_data_4096x4096.mrc /tmp/s13n-3646484/runs/e10474f3-07-p3-on/Movies/2019-06-22_01-14-22_808_eer_data_4096x4096.star            1    15.059557     0.920777    14.138780 
 
