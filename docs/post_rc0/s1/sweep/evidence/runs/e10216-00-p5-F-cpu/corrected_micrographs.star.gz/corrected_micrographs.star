
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     0.517000   300.000000     2.700000     0.100000     0.517000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographName #1 
_rlnMicrographMetadata #2 
_rlnOpticsGroup #3 
_rlnAccumMotionTotal #4 
_rlnAccumMotionEarly #5 
_rlnAccumMotionLate #6 
/mnt/clathrin/alex-motioncorr-s1/sweep/runs/e10216-00-p5-F-cpu/Movies/FoilHole_14961495_Data_14966722_14966723_20180615_1739_Fractions.mrc /mnt/clathrin/alex-motioncorr-s1/sweep/runs/e10216-00-p5-F-cpu/Movies/FoilHole_14961495_Data_14966722_14966723_20180615_1739_Fractions.star            1    69.060430    30.243511    38.816919 
 
