#!/bin/bash
# C1 iteration 3 (T24 with the retained-hash+STAR lane control, truth and recovery rows, A1 #249 GPU route), frozen before launch.
# Tested source e77a51a2 (exact checkout, existing binaries, no rebuild); tools packet 4facd76d deployed at tools-v2.3-run. GPU3, CPUs 8-9, max 2.
# Every stage is a c1_stage.sh stage (exclusive name, PID/exit receipts); the chain STOPS at the first stage whose exit is outside its allowed set and writes
# logs/chain-i3.stop. Allowed exits: lane control, N-vs-C1 comparison and attribution only 0; other comparisons 0 or 1 (valid IDENTICAL/DIFFERENT; 2 = INVALID stops);
# everything else only 0 (an A1 decoder-absent exit 77 therefore stops). No in-place retry, no CTest/sticky rerun, nothing repeated.
SC=/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb
export C1_SCR=$SC C1_SHA=e77a51a220cb0d91f4ac3c7fac211876d0c6833f C1_T24_DIR=t24-i3 PYTHONDONTWRITEBYTECODE=1
V=$SC/tools-v2.3-run; PY=/home/alex/.mc-venv/bin/python3; F=/mnt/clathrin/alex-motioncorr-rc0/W-QF; T=$SC/t24-i3; SP=/mnt/clathrin/alex-motioncorr-synth-combined
SCIPY=$SP/venv/bin/python3
cd $SC
until [ -f logs/chain-i3.go ]; do sleep 10; done          # released only by the parent's confirmation of the frozen plan
echo $$ > logs/chain-i3.pid; date -u +%FT%TZ > logs/chain-i3.started
go() { n=$1; ok=$2; shift 2; bash $V/c1_stage.sh "$n" "$@"; rc=$?
  case " $ok " in *" $rc "*) return 0;; esac
  { echo "stage $n exited $rc (allowed: $ok)"; date -u +%FT%TZ; } > logs/chain-i3.stop; exit 1; }
declare -A BIN=( [F-fresh]=$F/build-nvcomp/motioncorr [N]=$SC/attr/N/build/motioncorr [only254]=$SC/attr/only254/build/motioncorr [only260]=$SC/attr/only260/build/motioncorr [only270]=$SC/attr/only270/build/motioncorr [c1]=$SC/build-nvcomp/motioncorr )
for cfg in G L; do
  go i3-run-F-fresh-$cfg 0 $PY $V/c1_tutorial24.py run F-fresh ${BIN[F-fresh]} $cfg
  go i3-lane-hash-$cfg 0 $PY $V/c1_tutorial24.py lane-hash $cfg $F/multigpu/$cfg/s0 $F/multigpu/$cfg/cmp-w1_vs_s0-products.json $T/F-fresh-$cfg/out F-fresh_vs_F-retained-$cfg
  for a in c1 N only254 only260 only270; do
    go i3-run-$a-$cfg 0 $PY $V/c1_tutorial24.py run $a ${BIN[$a]} $cfg
    go i3-cmp-F-$a-$cfg "0 1" $PY $V/c1_tutorial24.py compare $T/F-fresh-$cfg/out $T/$a-$cfg/out F-fresh_vs_$a-$cfg
  done
  go i3-cmp-N-c1-$cfg 0 $PY $V/c1_tutorial24.py compare $T/N-$cfg/out $T/c1-$cfg/out N_vs_c1-$cfg
  for a in only254 only260 only270; do go i3-cmp-$a-c1-$cfg "0 1" $PY $V/c1_tutorial24.py compare $T/$a-$cfg/out $T/c1-$cfg/out ${a}_vs_c1-$cfg; done
  go i3-attribute-$cfg 0 $PY $V/c1_tutorial24.py attribute $cfg
done
for cfg in G L; do go i3-dataset-c1-$cfg 0 bash $V/c1_gpu_run.sh i3-ds-$cfg $PY $V/c1_tutorial24.py dataset c1 ${BIN[c1]} $cfg; done
go i3-v2-cpu 0 bash $V/c1_v2.sh cpu
go i3-v2-cuda 0 bash $V/c1_v2.sh cuda
go i3-r12 0 bash $V/c1_item.sh 12
go i3-r12ds 0 bash $V/c1_item.sh 12ds
go i3-r9-cuda 0 bash $V/c1_item.sh 9cuda
go i3-r9-nvcomp 0 bash $V/c1_item.sh 9nvcomp
# A1 (independent review): the #249 compressed-MRC decoder-status driver on the GPU route, unchanged driver, GPU3 lease held by c1_gpu_run.sh, pinned pbzip2 on PATH via c1_env.sh
for b in cuda nvcomp; do for c in bz2 xz zst; do
  go i3-a249-$b-$c 0 bash $V/c1_gpu_run.sh i3-a249-$b-$c taskset -c 8-9 $PY $SC/src/tests/test_compressed_mrc_status.py --binary $SC/build-$b/motioncorr --codec $c --gpu 0 --work $SC/a249/$b-$c
done; done
go i3-census-cuda 0 bash $V/c1_gpu_run.sh i3-census-cuda $PY $V/c1_census.py run cuda ${BIN[c1]} results-c1-cuda
go i3-census-cmp-cuda 0 $PY $V/c1_census.py compare results-c1-cuda $SP/results-plain270 cuda-none cuda $SC/census-cuda-vs-plain270.json
go i3-census-cmp-cuda-check 0 $PY -c "import json,sys;s=json.load(open('$SC/census-cuda-vs-plain270.json'))['summary'];print(s);sys.exit(0 if s['n']==100 and s['errors']==0 and s['nonzero_exit']==0 and s['sum_equal']==100 and s['star_equal']==100 else 1)"
go i3-census-metrics-cuda 0 $PY $V/c1_census.py metrics results-c1-cuda cuda $SC/census-cuda-metrics.json
for cfg in G L; do
  go i3-check-Fcpu-$cfg 0 grep -q '"rc": 0' $SC/t24/F-cpu-$cfg/RUN.json
  go i3-run-c1-cpu-$cfg 0 $PY $V/c1_tutorial24.py run c1-cpu $SC/build-cpu/motioncorr $cfg --cpu
  go i3-cmp-cpu-$cfg 0 $PY $V/c1_tutorial24.py compare $SC/t24/F-cpu-$cfg/out $T/c1-cpu-$cfg/out F-cpu_vs_c1-cpu-$cfg
done
go i3-census-cpu 0 $PY $V/c1_census.py run cpu $SC/build-cpu/motioncorr results-c1-cpu
go i3-census-metrics-cpu 0 $PY $V/c1_census.py metrics results-c1-cpu cpu $SC/census-cpu-metrics.json
go i3-image-cuda 0 env OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 $SCIPY $SC/src/docs/post_rc0/s1/synth_combined/image_batch.py eval $SC/census results-c1-cuda x 2
date -u +%FT%TZ > logs/chain-i3.finished; echo chain-done > logs/chain-i3.done
