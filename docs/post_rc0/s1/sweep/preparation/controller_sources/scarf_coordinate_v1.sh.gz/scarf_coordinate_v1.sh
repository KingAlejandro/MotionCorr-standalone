#!/bin/bash
# SPDX-License-Identifier: GPL-2.0-or-later
set -u
W=$HOME/mc-post-rc0-s1
exec 9>"$W/coordinate.lock"
flock -n 9 || exit 75
while [ ! -f "$W/build.exit" ] || [ ! -f "$W/build-bisect.exit" ]; do sleep 15; done
for file in build.exit build-bisect.exit; do
  rc=$(cat "$W/$file")
  [ "$rc" = 0 ] || { echo "$rc" > "$W/coordinate.exit"; exit "$rc"; }
done
for lane in a2 b2; do
  if [ "$lane" = a2 ]; then
    families=e10216,e10474f3
    older=--older
  else
    families=e10641,e12963,e10441,e10474f4,e10164
    older=
  fi
  if [ ! -e "$W/launch-$lane.pid" ]; then
    setsid nohup bash "$W/tools/scarf_launch_v2.sh" "$lane" "$families" $older > "$W/launch-$lane.out" 2>&1 < /dev/null &
    echo $! > "$W/launch-$lane.pid"
  fi
done
echo 0 > "$W/coordinate.exit"
