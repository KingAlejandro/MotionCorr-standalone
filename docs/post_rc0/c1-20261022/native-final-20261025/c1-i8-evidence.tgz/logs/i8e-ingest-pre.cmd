bash /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb-i8-20261025/tools-v3d-run/c1_ingest.sh pre /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb-i8-20261025/ingest-pre 
