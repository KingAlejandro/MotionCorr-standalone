#!/bin/bash
# SPDX-License-Identifier: GPL-2.0-or-later
set -u
W=/mnt/clathrin/alex-motioncorr-s1/sweep
# Caller uses taskset -c 96-103 and flock $W/breadth-driver.lock.
while [ ! -f "$W/fetch-breadth.exit" ]; do sleep 15; done
rc=$(cat "$W/fetch-breadth.exit")
if [ "$rc" != 0 ]; then
  echo "FETCH_FAILED rc=$rc"
else
  /home/alex/.mc-venv/bin/python3 "$W/tools/campaign.py" --root "$W" --all --wait-lock
  rc=$?
fi
echo "$rc" > "$W/breadth.exit"
exit "$rc"
