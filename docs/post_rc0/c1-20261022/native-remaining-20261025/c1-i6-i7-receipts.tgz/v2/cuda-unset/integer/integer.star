
# version 50001

data_general

_rlnImageSizeX                                      128
_rlnImageSizeY                                       96
_rlnImageSizeZ                                        5
_rlnMicrographMovieName                    integer.mrcs
_rlnMicrographBinning                          1.000000
_rlnMicrographOriginalPixelSize                0.885000
_rlnMicrographDoseRate                         1.000000
_rlnMicrographPreExposure                      0.000000
_rlnVoltage                                  300.000000
_rlnMicrographStartFrame                              1
_rlnMotionModelVersion                                0
 

# version 50001

data_global_shift

loop_ 
_rlnMicrographFrameNumber #1 
_rlnMicrographShiftX #2 
_rlnMicrographShiftY #3 
           1     0.000000     0.000000 
           2     -0.93333     1.666667 
           3     -2.16667     3.916667 
           4     -3.44762     6.133334 
           5     -4.10000     7.833333 
 
