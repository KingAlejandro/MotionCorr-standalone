#!/bin/bash
set -u
S=/mnt/clathrin/alex-motioncorr-253
export PATH=/home/alex/.mc-venv/bin:/usr/local/cuda-12.8/bin:$PATH
export CUDA_VISIBLE_DEVICES=GPU-b2cb2c39-8524-17fb-73a8-80cd61dbf83d CUDA_DEVICE_ORDER=PCI_BUS_ID OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1
export LD_LIBRARY_PATH=/usr/local/cuda-12.8/lib64:/home/alex/nvcomp53/nvcomp-linux-x86_64-5.3.0.16_cuda12-archive/lib
for ((i=0;i<180;i++)); do
 [ -f "$S/validation-stage.done" ] && break
 kill -0 2186210 2>/dev/null || exit 91
 sleep 10
done
[ -f "$S/validation-stage.done" ] || exit 92
run() { local label=$1; shift; flock -n /tmp/motioncorr-bench.lock true || return 90; "$@" > "$S/logs/$label.log" 2>&1; local rc=$?; echo $rc > "$S/logs/$label.exit"; return $rc; }
for ext in log exit xml; do cp "$S/logs/ctest-nvcomp.$ext" "$S/logs/ctest-nvcomp-initial.$ext"; done
run rebuild-final-nvcomp taskset -c 88-95 cmake --build "$S/build-fix-nvcomp" -j8 || exit $?
run ctest-nvcomp taskset -c 88-95 ctest --test-dir "$S/build-fix-nvcomp" -j1 --output-on-failure --output-junit "$S/logs/ctest-nvcomp.xml"
for stem in inverse-fixed inverse-mutant inverse-mutant-expected; do
 cp "$S/logs/$stem.log" "$S/logs/$stem-62b63b75.log"
 cp "$S/logs/$stem.exit" "$S/logs/$stem-62b63b75.exit"
done
run inverse-fixed taskset -c 88-95 "$S/build-fix-nvcomp/cuda_hermitian_inverse" --matrix
run inverse-mutant taskset -c 88-95 "$S/build-fix-nvcomp/cuda_hermitian_inverse_no_projection"
run inverse-mutant-expected taskset -c 88-95 "$S/build-fix-nvcomp/cuda_hermitian_inverse_no_projection" --expect-mismatch
run products taskset -c 88-95 python3 "$S/products.py" || exit $?
run analysis taskset -c 88-95 python3 "$S/analyze.py" || exit $?
run routes bash "$S/routes.sh" || exit $?
git -C "$S/src-fix" rev-parse HEAD > "$S/logs/source-final.txt"
git -C "$S/src-fix" status --porcelain > "$S/logs/source-final.status"
sha256sum "$S"/build-fix-{cpu,cuda,nvcomp}/motioncorr "$S/build-main-cuda/motioncorr" > "$S/logs/binaries.sha256"
echo done > "$S/finish-stage.done"
