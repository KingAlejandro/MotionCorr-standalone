#include "src/acc/cuda/cuda_hermitian.cuh"
#ifdef _CUDA_ENABLED

#include "src/acc/cuda/cuda_realspace_dw.h"
#include "src/acc/cuda/cuda_settings.h"
#include "src/error.h"

#include <cuda_runtime.h>
#include <cufft.h>
#include "src/acc/cuda/cuda_scoped_resources.h"
#include "src/stage_profile.h"
#include <cmath>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <vector>

#undef HANDLE_ERROR
#define HANDLE_ERROR(cmd) do { \
    cudaError_t err = (cmd); \
    if (err != cudaSuccess) { \
        logfile << "CUDA Error in " << __FILE__ << ":" << __LINE__ << " : " \
                << cudaGetErrorString(err) << std::endl; \
        if (failure) failure->record(err, __func__, __LINE__); \
        return false; \
    } \
} while (0)

#undef LAUNCH_HANDLE_ERROR
#define LAUNCH_HANDLE_ERROR(cmd) HANDLE_ERROR(cmd)

#define CUFFT_CHECK(cmd) do { \
    cufftResult result = (cmd); \
    if (result != CUFFT_SUCCESS) { \
        logfile << "cuFFT Error in " << __FILE__ << ":" << __LINE__ \
                << " : code " << result << std::endl; \
        if (failure) failure->recordCufft(result, __func__, __LINE__); \
        return false; \
    } \
} while (0)

namespace {
struct FramePolynomial {
    float x[6];
    float y[6];
};

FramePolynomial polynomialForFrame(const ThirdOrderPolynomialModel &model, int iframe) {
    const float z = (float)iframe, z2 = z * z, z3 = z * z2;
    FramePolynomial result;
    for (int i = 0; i < 6; ++i) {
        const int c = 3 * i;
        // Preserve RFLOAT coefficient arithmetic and cast only the completed sum.
        result.x[i] = (float)(model.coeffX(c) * z + model.coeffX(c + 1) * z2 + model.coeffX(c + 2) * z3);
        result.y[i] = (float)(model.coeffY(c) * z + model.coeffY(c + 1) * z2 + model.coeffY(c + 2) * z3);
    }
    return result;
}
} // namespace

// Reconstruction-scoped normalization: identical ascending dose sum and sqrt.
__global__ void computeDoseNormalizationKernel(
    float * __restrict__ d_normalization,
    int nfx, int nfy, int nfy_half,
    float nfx2, float nfy2, float apix,
    const float * __restrict__ d_doses,
    int n_frames)
{
    int x = blockIdx.x * blockDim.x + threadIdx.x;
    int y = blockIdx.y * blockDim.y + threadIdx.y;
    if (x >= nfx || y >= nfy) return;

    size_t idx = (size_t)y * nfx + x;
    int ly = (y > nfy_half) ? (y - nfy) : y;

    if (x == 0 && ly == 0) {
        d_normalization[idx] = sqrtf((float)n_frames);
        return;
    }

    float ly2 = (float)ly * (float)ly / nfy2;
    float dinv2 = ly2 + (float)x * (float)x / nfx2;
    float dinv = sqrtf(dinv2) / apix;
    float Ne = (0.245f * powf(dinv, -1.665f) + 2.81f) * 2.0f;

    float sum_weight_sq = 0.0f;
    for (int j = 0; j < n_frames; j++) {
        float w = expf(-d_doses[j] / Ne);
        sum_weight_sq += w * w;
    }

    d_normalization[idx] = sqrtf(sum_weight_sq);
}

// Dose weighting kernel implementing Grant & Grigorieff (2015) model.
// Out of place: reads the resident Fourier frame and writes the weighted frame
// straight into the C2R input scratch, so no per-frame copy of the frame is
// needed. Each output element is exactly the old in-place `x *= w` product
// (one IEEE multiply per component, same weight expression); only the source
// pointer differs. d_src and d_dst must not alias.
__global__ void applyDoseWeightKernel(
    const float2 * __restrict__ d_src,
    float2 * __restrict__ d_dst,
    int nfx, int nfy, int nfy_half,
    float nfx2, float nfy2, float apix,
    const float * __restrict__ d_doses,
    int n_frames, int iframe,
    const float * __restrict__ d_normalization)
{
    int x = blockIdx.x * blockDim.x + threadIdx.x;
    int y = blockIdx.y * blockDim.y + threadIdx.y;
    if (x >= nfx || y >= nfy) return;

    size_t idx = (size_t)y * nfx + x;
    int ly = (y > nfy_half) ? (y - nfy) : y;

    if (x == 0 && ly == 0) {
        float norm_weight = 1.0f / sqrtf((float)n_frames);
        const float2 v = d_src[idx];
        d_dst[idx].x = v.x * norm_weight;
        d_dst[idx].y = v.y * norm_weight;
        return;
    }

    float ly2 = (float)ly * (float)ly / nfy2;
    float dinv2 = ly2 + (float)x * (float)x / nfx2;
    float dinv = sqrtf(dinv2) / apix;
    float Ne = (0.245f * powf(dinv, -1.665f) + 2.81f) * 2.0f;

    float cur_weight = expf(-d_doses[iframe] / Ne);
    float norm_weight = cur_weight / d_normalization[idx];

    const float2 v = d_src[idx];
    d_dst[idx].x = v.x * norm_weight;
    d_dst[idx].y = v.y * norm_weight;
}

// Polynomial real-space bilinear interpolation & accumulation kernel
__global__ void interpolateAndAccumulatePolynomialKernel(
    float * __restrict__ d_Isum,
    float * __restrict__ d_Isum_sub,
    const float * __restrict__ d_Iframe,
    int nx, int ny,
    float x_C0, float x_C1, float x_C2, float x_C3, float x_C4, float x_C5,
    float y_C0, float y_C1, float y_C2, float y_C3, float y_C4, float y_C5)
{
    int ix = blockIdx.x * blockDim.x + threadIdx.x;
    int iy = blockIdx.y * blockDim.y + threadIdx.y;
    if (ix >= nx || iy >= ny) return;

    float x = (float)ix / (float)nx - 0.5f;
    float y = (float)iy / (float)ny - 0.5f;

    float x_fitted = x_C0 + (x_C1 + x_C2 * x) * x + (x_C3 + x_C4 * y + x_C5 * x) * y;
    float y_fitted = y_C0 + (y_C1 + y_C2 * x) * x + (y_C3 + y_C4 * y + y_C5 * x) * y;

    float x_target = (float)ix - x_fitted;
    float y_target = (float)iy - y_fitted;

    int x0 = (int)floorf(x_target);
    int y0 = (int)floorf(y_target);
    int x1 = x0 + 1;
    int y1 = y0 + 1;

    bool valid = true;
    if (x0 < 0 || x1 < 0) { x0 = 0; valid = false; }
    if (y0 < 0 || y1 < 0) { y0 = 0; valid = false; }
    if (x1 >= nx || x0 >= nx - 1) { x0 = nx - 1; valid = false; }
    if (y1 >= ny || y0 >= ny - 1) { y0 = ny - 1; valid = false; }

    float val;
    if (!valid) {
        val = d_Iframe[(size_t)y0 * nx + x0];
    } else {
        float fx = x_target - (float)x0;
        float fy = y_target - (float)y0;

        float d00 = d_Iframe[(size_t)y0 * nx + x0];
        float d01 = d_Iframe[(size_t)y0 * nx + x1];
        float d10 = d_Iframe[(size_t)y1 * nx + x0];
        float d11 = d_Iframe[(size_t)y1 * nx + x1];

        float dx0 = d00 + (d01 - d00) * fx;
        float dx1 = d10 + (d11 - d10) * fx;
        val = dx0 + (dx1 - dx0) * fy;
    }

    size_t out_idx = (size_t)iy * nx + ix;
    d_Isum[out_idx] += val;
    if (d_Isum_sub != nullptr) {
        d_Isum_sub[out_idx] += val;
    }
}

// Direct accumulation kernel for MOTION_MODEL_NULL
__global__ void accumulateDirectKernel(
    float * __restrict__ d_Isum,
    float * __restrict__ d_Isum_sub,
    const float * __restrict__ d_Iframe,
    size_t total_pixels)
{
    size_t idx = (size_t)blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < total_pixels) {
        float val = d_Iframe[idx];
        d_Isum[idx] += val;
        if (d_Isum_sub != nullptr) {
            d_Isum_sub[idx] += val;
        }
    }
}

bool cudaDoseWeightAndInterpolateDevice(
    const cufftComplex *d_Fframes,
    Image<float> &Isum,
    const int nx, const int ny, const int n_frames,
    const std::vector<RFLOAT> &doses,
    const RFLOAT apix,
    const ThirdOrderPolynomialModel *model,
    const int device_id,
    std::ostream &logfile,
    CudaFailureState *failure,
    cufftHandle borrowed_c2r,
    const DoseWeightScratch *scratch)
{
    if (n_frames == 0) return true;

    int dev_count = 0;
    cudaError_t count_err = cudaGetDeviceCount(&dev_count);
    if (count_err != cudaSuccess || dev_count == 0) {
        REPORT_ERROR("No CUDA capable devices found");
    }
    if (device_id < 0 || device_id >= dev_count) {
        REPORT_ERROR_STR("Invalid CUDA device ID: " << device_id << " (system has " << dev_count << " devices)");
    }
    HANDLE_ERROR(cudaSetDevice(device_id));

    mc_cuda::ScopedDeviceMemory<8> memory_cleanup(failure);
    mc_cuda::ScopedCudaEvents<8> event_cleanup(failure);
    mc_cuda::ScopedCufftPlan plan_cleanup(failure);

    const int nfx = nx / 2 + 1, nfy = ny;
    const int nfy_half = nfy / 2;
    const float nfy2 = (float)nfy * (float)nfy;
    const float nfx2 = (float)(nfx - 1) * (float)(nfx - 1) * 4.0f;
    const size_t sz_fframe = (size_t)nfy * nfx * sizeof(float2);
    const size_t sz_iframe = (size_t)ny * nx * sizeof(float);
    const size_t sz_normalization = (size_t)nfy * nfx * sizeof(float);

    cudaEvent_t ev_start_total, ev_stop_total;
    cudaEvent_t ev_start_dw, ev_stop_dw;
    cudaEvent_t ev_start_cufft, ev_stop_cufft;
    cudaEvent_t ev_start_interp, ev_stop_interp;

    HANDLE_ERROR(cudaEventCreate(&ev_start_total));
    event_cleanup.add(ev_start_total);
    HANDLE_ERROR(cudaEventCreate(&ev_stop_total));
    event_cleanup.add(ev_stop_total);
    HANDLE_ERROR(cudaEventCreate(&ev_start_dw));
    event_cleanup.add(ev_start_dw);
    HANDLE_ERROR(cudaEventCreate(&ev_stop_dw));
    event_cleanup.add(ev_stop_dw);
    HANDLE_ERROR(cudaEventCreate(&ev_start_cufft));
    event_cleanup.add(ev_start_cufft);
    HANDLE_ERROR(cudaEventCreate(&ev_stop_cufft));
    event_cleanup.add(ev_stop_cufft);
    HANDLE_ERROR(cudaEventCreate(&ev_start_interp));
    event_cleanup.add(ev_start_interp);
    HANDLE_ERROR(cudaEventCreate(&ev_stop_interp));
    event_cleanup.add(ev_stop_interp);

    HANDLE_ERROR(cudaEventRecord(ev_start_total));

    float2 *d_Fframe = nullptr;
    float *d_Iframe = nullptr;
    float *d_Isum = nullptr;
    float *d_doses = nullptr;
    float *d_normalization = nullptr;

    size_t total_vram_allocated = 0;
    if (scratch == nullptr) {
        // Reconstruction-owned buffers, one allocation each (the fallback path).
        HANDLE_ERROR(cudaMalloc((void**)&d_Fframe, sz_fframe));
        memory_cleanup.add(d_Fframe);
        total_vram_allocated += sz_fframe;

        HANDLE_ERROR(cudaMalloc((void**)&d_Iframe, sz_iframe));
        memory_cleanup.add(d_Iframe);
        total_vram_allocated += sz_iframe;

        HANDLE_ERROR(cudaMalloc((void**)&d_Isum, sz_iframe));
        memory_cleanup.add(d_Isum);
        total_vram_allocated += sz_iframe;

        HANDLE_ERROR(cudaMalloc((void**)&d_doses, n_frames * sizeof(float)));
        memory_cleanup.add(d_doses);
        total_vram_allocated += n_frames * sizeof(float);

        HANDLE_ERROR(cudaMalloc((void**)&d_normalization, sz_normalization));
        memory_cleanup.add(d_normalization);
        total_vram_allocated += sz_normalization;
    } else {
        // Session mode: the C2R input frame is the caller's existing scratch
        // tile, and the other four buffers share one allocation (one cudaMalloc
        // and one checked cudaFree instead of four of each).
        d_Fframe = (float2*)scratch->fourier;
        const mc_cuda::DoseScratchLayout layout = mc_cuda::doseScratchLayout(nx, ny, n_frames);
        char *block = scratch->block;
        if (!block) {
            HANDLE_ERROR(cudaMalloc((void**)&block, layout.total_bytes));
            memory_cleanup.add(block);
            total_vram_allocated += layout.total_bytes;
        }
        d_Isum = (float*)(block + layout.accumulator_offset);
        d_Iframe = (float*)(block + layout.real_offset);
        d_normalization = (float*)(block + layout.normalization_offset);
        d_doses = (float*)(block + layout.doses_offset);
    }
    HANDLE_ERROR(cudaMemset(d_Isum, 0, sz_iframe));

    std::vector<float> h_doses(n_frames);
    for (int i = 0; i < n_frames; i++) h_doses[i] = (float)doses[i];
    HANDLE_ERROR(cudaMemcpy(d_doses, h_doses.data(), n_frames * sizeof(float), cudaMemcpyHostToDevice));

    // The resident session already owns the same geometry/type/batch plan.
    // All executions and their completion events use stream0, so borrowing its
    // live shared work area cannot overlap another session transform. Only the
    // zero-handle fallback creates an owner; borrowed handles never enter RAII.
    cufftHandle plan_c2r = borrowed_c2r;
    if (plan_c2r == 0) {
        int n[2] = {ny, nx};
        CUFFT_CHECK(cufftCreate(&plan_c2r));
        plan_cleanup.take(plan_c2r);
        size_t plan_work_bytes = 0;
        CUFFT_CHECK(cufftMakePlanMany(plan_c2r, 2, n, NULL, 1, 0, NULL, 1, 0, CUFFT_C2R, 1, &plan_work_bytes));
        size_t cufft_work_size = 0;
        CUFFT_CHECK(cufftGetSize(plan_c2r, &cufft_work_size));
        total_vram_allocated += cufft_work_size;
    }

    dim3 blockDW(16, 16);
    dim3 gridDW((nfx + 15) / 16, (nfy + 15) / 16);

    dim3 blockInterp(16, 16);
    dim3 gridInterp((nx + 15) / 16, (ny + 15) / 16);

    // Complete normalization before any frame consumes its plane. This stays
    // inside setup-inclusive reconstruction timing and dose-kernel telemetry.
    HANDLE_ERROR(cudaEventRecord(ev_start_dw));
    computeDoseNormalizationKernel<<<gridDW, blockDW>>>(
        d_normalization, nfx, nfy, nfy_half, nfx2, nfy2, (float)apix, d_doses, n_frames
    );
    LAUNCH_HANDLE_ERROR(cudaGetLastError());
    HANDLE_ERROR(cudaEventRecord(ev_stop_dw));
    HANDLE_ERROR(cudaEventSynchronize(ev_stop_dw));
    float total_dw_ms = 0.0f;
    HANDLE_ERROR(cudaEventElapsedTime(&total_dw_ms, ev_start_dw, ev_stop_dw));
    float total_cufft_ms = 0.0f;
    float total_interp_ms = 0.0f;
    // Per-frame event timing exists only for the log; each timed stage forces a
    // host wait. Without --profile the frames queue in order on stream 0: the
    // weight, C2R and accumulate are stream-ordered, the checked
    // normalization completion above still precedes the first frame, and the
    // final blocking download is the completion point. #139 measured this shape
    // at -2.31 ms/movie (161/168 movies faster) with bit-exact products.
    const bool timed = StageProfile::instance().deviceTiming();

    for (int iframe = 0; iframe < n_frames; iframe++) {
        // The weight kernel reads the resident frame and writes the weighted
        // frame into the C2R input scratch: no per-frame device copy, and the
        // resident Fourier frame is never written.
        const float2 *src_frame = (const float2*)d_Fframes + (size_t)iframe * nfy * nfx;

        // Dose weighting
        if (timed) HANDLE_ERROR(cudaEventRecord(ev_start_dw));
        applyDoseWeightKernel<<<gridDW, blockDW>>>(
            src_frame, d_Fframe, nfx, nfy, nfy_half, nfx2, nfy2, (float)apix, d_doses, n_frames, iframe, d_normalization
        );
        LAUNCH_HANDLE_ERROR(cudaGetLastError());
        if (timed) {
            HANDLE_ERROR(cudaEventRecord(ev_stop_dw));
            HANDLE_ERROR(cudaEventSynchronize(ev_stop_dw));
            float dw_ms = 0.0f;
            HANDLE_ERROR(cudaEventElapsedTime(&dw_ms, ev_start_dw, ev_stop_dw));
            total_dw_ms += dw_ms;
        }

        // Inverse FFT
        if (timed) HANDLE_ERROR(cudaEventRecord(ev_start_cufft));
        LAUNCH_HANDLE_ERROR(cudaSuccess);
        CUFFT_CHECK(cufftExecC2R(plan_c2r, (cufftComplex*)d_Fframe, (cufftReal*)d_Iframe));
        if (timed) {
            HANDLE_ERROR(cudaEventRecord(ev_stop_cufft));
            HANDLE_ERROR(cudaEventSynchronize(ev_stop_cufft));
            float cufft_ms = 0.0f;
            HANDLE_ERROR(cudaEventElapsedTime(&cufft_ms, ev_start_cufft, ev_stop_cufft));
            total_cufft_ms += cufft_ms;
        }

        // Interpolate and accumulate
        if (timed) HANDLE_ERROR(cudaEventRecord(ev_start_interp));
        if (model != nullptr) {
            const FramePolynomial coeff = polynomialForFrame(*model, iframe);

            interpolateAndAccumulatePolynomialKernel<<<gridInterp, blockInterp>>>(
                d_Isum, nullptr, d_Iframe, nx, ny,
                coeff.x[0], coeff.x[1], coeff.x[2], coeff.x[3], coeff.x[4], coeff.x[5],
                coeff.y[0], coeff.y[1], coeff.y[2], coeff.y[3], coeff.y[4], coeff.y[5]
            );
        } else {
            size_t total_pixels = (size_t)ny * nx;
            int block1D = 256;
            int grid1D = (total_pixels + block1D - 1) / block1D;
            accumulateDirectKernel<<<grid1D, block1D>>>(d_Isum, nullptr, d_Iframe, total_pixels);
        }
        LAUNCH_HANDLE_ERROR(cudaGetLastError());
        if (timed) {
            HANDLE_ERROR(cudaEventRecord(ev_stop_interp));
            HANDLE_ERROR(cudaEventSynchronize(ev_stop_interp));
            float interp_ms = 0.0f;
            HANDLE_ERROR(cudaEventElapsedTime(&interp_ms, ev_start_interp, ev_stop_interp));
            total_interp_ms += interp_ms;
        }
    }

    // Single D2H download of reconstructed image. Staging it through a pinned
    // buffer was measured and rejected (docs/host_device_overheads.md): the
    // extra 57 MB host copy costs more than the faster PCIe transfer saves.
    HANDLE_ERROR(cudaMemcpy(Isum().data, d_Isum, sz_iframe, cudaMemcpyDeviceToHost));

    HANDLE_ERROR(cudaEventRecord(ev_stop_total));
    HANDLE_ERROR(cudaEventSynchronize(ev_stop_total));
    float total_ms = 0.0f;
    HANDLE_ERROR(cudaEventElapsedTime(&total_ms, ev_start_total, ev_stop_total));

    logfile << " [CUDA Dose-Weighted Reconstruction Profile (Resident VRAM)]" << std::endl;
    logfile << "  Device: " << device_id << ", Frames: " << n_frames << ", Size: " << nx << "x" << ny << std::endl;
    logfile << "  Peak VRAM: " << std::fixed << std::setprecision(2)
            << (total_vram_allocated / (1024.0 * 1024.0)) << " MiB" << std::endl;
    if (timed) {
        logfile << "  Dose Weighting Kernel: " << total_dw_ms << " ms" << std::endl;
        logfile << "  cuFFT C2R Execution:   " << total_cufft_ms << " ms" << std::endl;
        logfile << "  Interpolation & Accum: " << total_interp_ms << " ms" << std::endl;
    } else {
        logfile << "  Per-stage timing:      not measured (enable with --profile)" << std::endl;
    }
    logfile << "  Total DW Reconstruction Time: " << total_ms << " ms" << std::endl;

    const cufftResult plan_release = plan_cleanup.releaseAll();
    const cudaError_t memory_release = memory_cleanup.releaseAll();
    const cudaError_t event_release = event_cleanup.releaseAll();
    CUFFT_CHECK(plan_release);
    HANDLE_ERROR(memory_release);
    HANDLE_ERROR(event_release);
    return true;
}

bool cudaDoseWeightAndInterpolate(
    const std::vector<MultidimArray<fComplex> > &Fframes,
    Image<float> &Isum,
    const std::vector<RFLOAT> &doses,
    const RFLOAT apix,
    const ThirdOrderPolynomialModel *model,
    const int device_id,
    std::ostream &logfile,
    CudaFailureState *failure)
{
    const int n_frames = Fframes.size();
    if (n_frames == 0) return true;

    const int nfx = XSIZE(Fframes[0]), nfy = YSIZE(Fframes[0]);
    const int nx = (nfx - 1) * 2, ny = nfy;
    const size_t sz_fframes = (size_t)n_frames * nfy * nfx * sizeof(float2);

    mc_cuda::ScopedDeviceMemory<8> memory_cleanup(failure);
    float2 *d_Fframes = nullptr;
    HANDLE_ERROR(cudaSetDevice(device_id));
    HANDLE_ERROR(cudaMalloc((void**)&d_Fframes, sz_fframes));
    memory_cleanup.add(d_Fframes);

    for (int iframe = 0; iframe < n_frames; iframe++) {
        HANDLE_ERROR(cudaMemcpy(
            d_Fframes + (size_t)iframe * nfy * nfx,
            Fframes[iframe].data,
            (size_t)nfy * nfx * sizeof(float2),
            cudaMemcpyHostToDevice
        ));
    }

    bool res = cudaDoseWeightAndInterpolateDevice(
        (const cufftComplex*)d_Fframes, Isum, nx, ny, n_frames, doses, apix, model, device_id, logfile, failure
    );

    const cudaError_t memory_release = memory_cleanup.releaseAll();
    HANDLE_ERROR(memory_release);
    return res;
}

bool cudaRealSpaceInterpolationDevice(
    const float *d_Iframes,
    Image<float> &Isum,
    Image<float> *Isum_even,
    Image<float> *Isum_odd,
    const int nx, const int ny, const int n_frames,
    const ThirdOrderPolynomialModel *model,
    const int device_id,
    std::ostream &logfile,
    CudaFailureState *failure)
{
    if (n_frames == 0) return true;

    int dev_count = 0;
    cudaError_t count_err = cudaGetDeviceCount(&dev_count);
    if (count_err != cudaSuccess || dev_count == 0) {
        REPORT_ERROR("No CUDA capable devices found");
    }
    if (device_id < 0 || device_id >= dev_count) {
        REPORT_ERROR_STR("Invalid CUDA device ID: " << device_id << " (system has " << dev_count << " devices)");
    }
    HANDLE_ERROR(cudaSetDevice(device_id));

    mc_cuda::ScopedDeviceMemory<8> memory_cleanup(failure);
    mc_cuda::ScopedCudaEvents<8> event_cleanup(failure);

    const size_t sz_iframe = (size_t)ny * nx * sizeof(float);

    cudaEvent_t ev_start_total, ev_stop_total;
    HANDLE_ERROR(cudaEventCreate(&ev_start_total));
    event_cleanup.add(ev_start_total);
    HANDLE_ERROR(cudaEventCreate(&ev_stop_total));
    event_cleanup.add(ev_stop_total);
    HANDLE_ERROR(cudaEventRecord(ev_start_total));

    float *d_Isum = nullptr;
    float *d_Isum_even = nullptr;
    float *d_Isum_odd = nullptr;

    size_t total_vram_allocated = 0;
    HANDLE_ERROR(cudaMalloc((void**)&d_Isum, sz_iframe));
    memory_cleanup.add(d_Isum);
    total_vram_allocated += sz_iframe;
    HANDLE_ERROR(cudaMemset(d_Isum, 0, sz_iframe));

    if (Isum_even != nullptr && Isum_odd != nullptr) {
        HANDLE_ERROR(cudaMalloc((void**)&d_Isum_even, sz_iframe));
        memory_cleanup.add(d_Isum_even);
        total_vram_allocated += sz_iframe;
        HANDLE_ERROR(cudaMemset(d_Isum_even, 0, sz_iframe));

        HANDLE_ERROR(cudaMalloc((void**)&d_Isum_odd, sz_iframe));
        memory_cleanup.add(d_Isum_odd);
        total_vram_allocated += sz_iframe;
        HANDLE_ERROR(cudaMemset(d_Isum_odd, 0, sz_iframe));
    }

    dim3 blockInterp(16, 16);
    dim3 gridInterp((nx + 15) / 16, (ny + 15) / 16);

    for (int iframe = 0; iframe < n_frames; iframe++) {
        const float *d_Iframe = d_Iframes + (size_t)iframe * ny * nx;

        float *d_sub = nullptr;
        if (d_Isum_even != nullptr && d_Isum_odd != nullptr) {
            d_sub = (iframe % 2 == 0) ? d_Isum_even : d_Isum_odd;
        }

        if (model != nullptr) {
            const FramePolynomial coeff = polynomialForFrame(*model, iframe);

            interpolateAndAccumulatePolynomialKernel<<<gridInterp, blockInterp>>>(
                d_Isum, d_sub, d_Iframe, nx, ny,
                coeff.x[0], coeff.x[1], coeff.x[2], coeff.x[3], coeff.x[4], coeff.x[5],
                coeff.y[0], coeff.y[1], coeff.y[2], coeff.y[3], coeff.y[4], coeff.y[5]
            );
        } else {
            size_t total_pixels = (size_t)ny * nx;
            int block1D = 256;
            int grid1D = (total_pixels + block1D - 1) / block1D;
            accumulateDirectKernel<<<grid1D, block1D>>>(d_Isum, d_sub, d_Iframe, total_pixels);
        }
        LAUNCH_HANDLE_ERROR(cudaGetLastError());
    }

    // Download final sum
    HANDLE_ERROR(cudaMemcpy(Isum().data, d_Isum, sz_iframe, cudaMemcpyDeviceToHost));
    if (Isum_even != nullptr && Isum_odd != nullptr) {
        HANDLE_ERROR(cudaMemcpy((*Isum_even)().data, d_Isum_even, sz_iframe, cudaMemcpyDeviceToHost));
        HANDLE_ERROR(cudaMemcpy((*Isum_odd)().data, d_Isum_odd, sz_iframe, cudaMemcpyDeviceToHost));
    }

    HANDLE_ERROR(cudaEventRecord(ev_stop_total));
    HANDLE_ERROR(cudaEventSynchronize(ev_stop_total));
    float total_ms = 0.0f;
    HANDLE_ERROR(cudaEventElapsedTime(&total_ms, ev_start_total, ev_stop_total));

    logfile << " [CUDA Unweighted Reconstruction Profile (Resident VRAM)]" << std::endl;
    logfile << "  Device: " << device_id << ", Frames: " << n_frames << ", Size: " << nx << "x" << ny << std::endl;
    logfile << "  Peak VRAM: " << std::fixed << std::setprecision(2)
            << (total_vram_allocated / (1024.0 * 1024.0)) << " MiB" << std::endl;
    logfile << "  Total Unweighted Reconstruction Time: " << total_ms << " ms" << std::endl;

    const cudaError_t memory_release = memory_cleanup.releaseAll();
    const cudaError_t event_release = event_cleanup.releaseAll();
    HANDLE_ERROR(memory_release);
    HANDLE_ERROR(event_release);
    return true;
}

bool cudaRealSpaceInterpolation(
    Image<float> &Isum,
    Image<float> *Isum_even,
    Image<float> *Isum_odd,
    const std::vector<Image<float> > &Iframes,
    const ThirdOrderPolynomialModel *model,
    const int device_id,
    std::ostream &logfile,
    CudaFailureState *failure)
{
    const int n_frames = Iframes.size();
    if (n_frames == 0) return true;

    const int nx = XSIZE(Iframes[0]()), ny = YSIZE(Iframes[0]());
    const size_t sz_iframes = (size_t)n_frames * ny * nx * sizeof(float);

    mc_cuda::ScopedDeviceMemory<8> memory_cleanup(failure);
    float *d_Iframes = nullptr;
    HANDLE_ERROR(cudaSetDevice(device_id));
    HANDLE_ERROR(cudaMalloc((void**)&d_Iframes, sz_iframes));
    memory_cleanup.add(d_Iframes);

    for (int iframe = 0; iframe < n_frames; iframe++) {
        HANDLE_ERROR(cudaMemcpy(
            d_Iframes + (size_t)iframe * ny * nx,
            Iframes[iframe]().data,
            (size_t)ny * nx * sizeof(float),
            cudaMemcpyHostToDevice
        ));
    }

    bool res = cudaRealSpaceInterpolationDevice(
        d_Iframes, Isum, Isum_even, Isum_odd, nx, ny, n_frames, model, device_id, logfile, failure
    );

    const cudaError_t memory_release = memory_cleanup.releaseAll();
    HANDLE_ERROR(memory_release);
    return res;
}

#endif // _CUDA_ENABLED
