/home/alex/.mc-venv/bin/python3 /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/tools-v2.2-run/c1_tutorial24.py run F-fresh /mnt/clathrin/alex-motioncorr-rc0/W-QF/build-nvcomp/motioncorr G 
