
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     1.000000   300.000000     2.700000     0.100000     1.000000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographName #1 
_rlnMicrographMetadata #2 
_rlnOpticsGroup #3 
_rlnAccumMotionTotal #4 
_rlnAccumMotionEarly #5 
_rlnAccumMotionLate #6 
/mnt/clathrin/alex-226-d2-d3-integration-20261022T154900Z/matrix/healthy-plan/Movies/a.mrc /mnt/clathrin/alex-226-d2-d3-integration-20261022T154900Z/matrix/healthy-plan/Movies/a.star            1     7.691090     4.618517     3.072573 
/mnt/clathrin/alex-226-d2-d3-integration-20261022T154900Z/matrix/healthy-plan/Movies/b.mrc /mnt/clathrin/alex-226-d2-d3-integration-20261022T154900Z/matrix/healthy-plan/Movies/b.star            1     7.691090     4.618517     3.072573 
 
