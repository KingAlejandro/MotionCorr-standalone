bash /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb-i8-20261025/tools-v3c-run/c1_attr_build8.sh N21093 
