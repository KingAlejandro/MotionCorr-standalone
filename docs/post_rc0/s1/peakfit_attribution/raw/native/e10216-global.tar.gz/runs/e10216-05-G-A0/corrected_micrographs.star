
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     0.517000   300.000000     2.700000     0.100000     0.517000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographNameNoDW #1 
_rlnMicrographName #2 
_rlnMicrographMetadata #3 
_rlnOpticsGroup #4 
_rlnAccumMotionTotal #5 
_rlnAccumMotionEarly #6 
_rlnAccumMotionLate #7 
/mnt/clathrin/alex-motioncorr-peakfit/runs/e10216-05-G-A0/Movies/FoilHole_14963739_Data_14966722_14966723_20180616_2325_Fractions_noDW.mrc /mnt/clathrin/alex-motioncorr-peakfit/runs/e10216-05-G-A0/Movies/FoilHole_14963739_Data_14966722_14966723_20180616_2325_Fractions.mrc /mnt/clathrin/alex-motioncorr-peakfit/runs/e10216-05-G-A0/Movies/FoilHole_14963739_Data_14966722_14966723_20180616_2325_Fractions.star            1    53.662385    14.987370    38.675015 
 
