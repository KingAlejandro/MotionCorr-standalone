#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-or-later
"""Historical recovery: record missing launcher status, release completed owned allocation."""
import json
from pathlib import Path
import subprocess

root = Path.home() / 'mc-post-rc0-s1'
job = '3645685'
records = list((root / ('venue-' + job + '-recovery') / 'analysis').glob('*-F-cuda.json'))
assert len(records) == 34
for path in records:
    pair = json.loads(path.read_text())
    for label in (pair['reference'], pair['test']):
        run = json.loads((path.parent.parent / 'runs' / label / 'run.json').read_text())
        assert run['exit_status'] == 0
        if run['gpu']:
            assert run['gpu_witness_uuids'] == [run['requested_gpu_uuid']]
cmd = ['sacct', '-j', job, '--format=JobID,JobName,State,ExitCode,NodeList', '-P']
r = subprocess.run(cmd, capture_output=True, text=True)
assert r.returncode == 0
rows = [line.split('|') for line in r.stdout.splitlines()[1:] if line.strip()]
assert any(x[:4] == [job + '.0', 'bash', 'COMPLETED', '0:0'] for x in rows), rows
assert all(x[2] == 'COMPLETED' and x[3] == '0:0' for x in rows if x[0] not in (job, job + '.extern')), rows
assert any(x[0] == job and x[1] == 'mcs1-b5' for x in rows), rows
out = root / 'launch-b5/completion-recovery.json'
assert not out.exists()
record = dict(job=job, original_launcher_exit_status='not retained; exit/release sentinels missing',
              numerical_pairs=34, all_pair_native_exits_zero=True,
              native_campaign_step='3645685.0', native_campaign_step_state='COMPLETED',
              native_campaign_step_exit_code='0:0', accounting_argv=cmd,
              accounting_exit_status=r.returncode, accounting_stdout=r.stdout,
              action='release owned allocation after all non-extern steps completed successfully')
release = ['scancel', job]
s = subprocess.run(release, capture_output=True, text=True)
record.update(release_argv=release, release_exit_status=s.returncode, release_stdout=s.stdout, release_stderr=s.stderr)
out.write_text(json.dumps(record, indent=2) + '\n')
assert s.returncode == 0
print(json.dumps(record, indent=2))
