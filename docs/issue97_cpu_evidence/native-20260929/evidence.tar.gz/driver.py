import hashlib,json,sys,traceback
from pathlib import Path
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'src/tests'))
import test_runner_contract as contract
sys.path.insert(0,str(R))
import compare_output_trees as comparator
results={}
for label in ('candidate','main'):
    work=R/('products-'+label)
    work.mkdir()
    try:
        contract.interpolate_shifts(R/('build-'+label)/'motioncorr',work,gpu=0)
    except AssertionError as e:
        results[label]={'pass':False,'error':repr(e)}
        if label=='candidate':
            (R/'driver-result.json').write_text(json.dumps(results,indent=2))
            raise
    else:
        results[label]={'pass':True}
    for arm in ('off','on'):
        log=(work/arm/'synthetic_128x128_8frames.log').read_text()
        assert log.count('[CUDA Patch Alignment] completed; converged=yes')==9
        assert '[CUDA Patch Alignment] completed; converged=no' not in log
        assert 'Frames to be used: 2 3 4 5 6 7 8' in log
        assert ' | 2 3 | 4 5 | 6 7 8 | ' in log
assert results['candidate']['pass'] and not results['main']['pass'],results
# Attribute the old-source rejection to the intended anchor defect explicitly.
w=R/'products-main'
on=contract.read_local_shifts(w/'on/synthetic_128x128_8frames.star')
off=contract.read_local_shifts(w/'off/synthetic_128x128_8frames.star')
assert len(on)==len(off)==9
anchor_failures=sum(on[p][3][a]!=off[p][3][a] for p in on for a in (0,1))
assert anchor_failures==18,anchor_failures
results['main']['native_anchor_failures']=anchor_failures
manifest={'movies':['synthetic_128x128_8frames.mrcs'],'expected_shape_xyz':[128,128,1]}
for arm in ('off','on'):
    report=comparator.compare_trees(R/'products-main'/arm,R/'products-candidate'/arm,manifest,compare_auxiliary=False)
    (R/('comparison-'+arm+'.json')).write_text(json.dumps(report,indent=2))
    assert report['status']==('PASS' if arm=='off' else 'FAIL'),report
    results[arm]={'status':report['status'],'different_products':report['different_products']}
(R/'driver-result.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
