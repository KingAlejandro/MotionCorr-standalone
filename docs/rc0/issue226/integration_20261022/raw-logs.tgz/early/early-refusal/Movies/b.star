
# version 50001

data_general

_rlnImageSizeX                                       48
_rlnImageSizeY                                       40
_rlnImageSizeZ                                        6
_rlnMicrographMovieName                    Movies/b.mrcs
_rlnMicrographBinning                          1.000000
_rlnMicrographOriginalPixelSize                1.000000
_rlnMicrographDoseRate                         1.000000
_rlnMicrographPreExposure                      0.000000
_rlnVoltage                                  300.000000
_rlnMicrographStartFrame                              1
_rlnMotionModelVersion                                0
 

# version 50001

data_global_shift

loop_ 
_rlnMicrographFrameNumber #1 
_rlnMicrographShiftX #2 
_rlnMicrographShiftY #3 
           1     0.000000     0.000000 
           2     -0.95362     -1.08183 
           3     -1.77319     0.045631 
           4     -3.06810     -1.17935 
           5     -4.03664     -0.02216 
           6     -5.12184     -1.14778 
 

# version 50001

data_hot_pixels

loop_ 
_rlnCoordinateX #1 
_rlnCoordinateY #2 
   24.000000    20.000000 
   25.000000    20.000000 
   26.000000    20.000000 
   27.000000    20.000000 
   28.000000    20.000000 
   26.000000    21.000000 
   27.000000    21.000000 
   28.000000    21.000000 
   29.000000    21.000000 
 
