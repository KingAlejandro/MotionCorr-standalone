#!/bin/bash
set -u
S=/mnt/clathrin/alex-motioncorr-253
export PATH=/home/alex/.mc-venv/bin:/usr/local/cuda-12.8/bin:$PATH
export CUDA_VISIBLE_DEVICES=GPU-b2cb2c39-8524-17fb-73a8-80cd61dbf83d CUDA_DEVICE_ORDER=PCI_BUS_ID
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1
export LD_LIBRARY_PATH=/usr/local/cuda-12.8/lib64:/home/alex/nvcomp53/nvcomp-linux-x86_64-5.3.0.16_cuda12-archive/lib
run() { local label=$1; shift; "$@" > "$S/logs/$label.log" 2>&1; local rc=$?; echo $rc > "$S/logs/$label.exit"; return $rc; }
# Earlier test-setup error stays retained.
cp "$S/logs/inverse-fixed.log" "$S/logs/inverse-fixed-initial.log"
cp "$S/logs/inverse-fixed.exit" "$S/logs/inverse-fixed-initial.exit"
run rebuild-fix taskset -c 88-95 cmake --build "$S/build-fix-nvcomp" -j8 || exit $?
run inverse-fixed taskset -c 88-95 "$S/build-fix-nvcomp/cuda_hermitian_inverse" --matrix
run inverse-mutant taskset -c 88-95 "$S/build-fix-nvcomp/cuda_hermitian_inverse_no_projection"
run inverse-mutant-expected taskset -c 88-95 "$S/build-fix-nvcomp/cuda_hermitian_inverse_no_projection" --expect-mismatch
run ctest-nvcomp taskset -c 88-95 ctest --test-dir "$S/build-fix-nvcomp" -j1 --output-on-failure --output-junit "$S/logs/ctest-nvcomp.xml"
cu=(-DCUDA=ON -DCMAKE_CUDA_ARCHITECTURES=80 -DCMAKE_CUDA_COMPILER=/usr/local/cuda-12.8/bin/nvcc -DCUDAToolkit_ROOT=/usr/local/cuda-12.8)
for type in cpu cuda; do
 opts=(-DCUDA=OFF)
 if [ "$type" = cuda ]; then opts=("${cu[@]}" -DUSE_NVCOMP=OFF); fi
 run configure-fix-$type taskset -c 88-95 cmake -S "$S/src-fix" -B "$S/build-fix-$type" -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON -DPython3_EXECUTABLE=/home/alex/.mc-venv/bin/python3 "${opts[@]}" || exit $?
 run build-fix-$type taskset -c 88-95 cmake --build "$S/build-fix-$type" -j8 || exit $?
 run ctest-$type taskset -c 88-95 ctest --test-dir "$S/build-fix-$type" -j1 --output-on-failure --output-junit "$S/logs/ctest-$type.xml"
done
echo done > "$S/validation-stage.done"
