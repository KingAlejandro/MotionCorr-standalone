# version 30001

data_optics

loop_
_rlnOpticsGroupName #1
_rlnOpticsGroup #2
_rlnMicrographOriginalPixelSize #3
_rlnVoltage #4
_rlnSphericalAberration #5
_rlnAmplitudeContrast #6
opticsGroup1            1     0.885000   200.000000     1.400000     0.100000
'optics group two'      2     1.070000   300.000000     2.700000     0.070000

data_movies

loop_
_rlnMicrographMovieName #1
_rlnOpticsGroup #2
_rlnMicrographPreExposure #3
Movies/mov_04.tiff 1 5.600000
Movies/mov_05.tiff 2 7.000000

