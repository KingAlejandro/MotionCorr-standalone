import fcntl,pathlib,time,os
p=pathlib.Path('/mnt/clathrin/alex-motioncorr-253')
f=open('/tmp/motioncorr-gpu3-correctness.lock','a');fcntl.flock(f,fcntl.LOCK_EX)
with open('/tmp/motioncorr-bench.lock','a') as bench:
 fcntl.flock(bench,fcntl.LOCK_EX|fcntl.LOCK_NB)
 fcntl.flock(bench,fcntl.LOCK_UN)
(p/'lease-lane.ready').write_text(str(os.getpid()))
while not (p/'lease-lane.stop').exists():time.sleep(1)
