#!/bin/bash
# One-off orchestration (hash recorded in the evidence): sticky rows inside the parent-granted window 19:40Z-20:10Z with CPUs 8-9,14-15.
export C1_SCR=/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb C1_SHA=e77a51a220cb0d91f4ac3c7fac211876d0c6833f C1_STICKY_CPUS=8-9,14-15
T=/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/src/docs/post_rc0/c1-20261022/tools
cd /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb
until [ -f logs/build-nvcomp.exit ]; do sleep 5; done
for cfg in nvcomp cuda; do
  now=$(date -u +%H%M)
  if [ "$now" -ge 1958 ] && [ $cfg = cuda ]; then echo "$(date -u +%FT%TZ) not starting sticky-$cfg: too close to the 20:10Z window end; row stays UNRUN" > logs/sticky-$cfg.not-started; break; fi
  ps -eo pid,user,psr,pcpu,args --sort=-pcpu | awk 'NR==1 || $3==14 || $3==15' | head -8 | cut -c1-160 > logs/sticky-$cfg-lane1415-pre.txt
  bash $T/c1_stage.sh sticky-$cfg bash $T/c1_sticky.sh $cfg
done
echo chain-done > logs/chain-sticky.done
