taskset -c 40-47 cmake --build /mnt/clathrin/alex-motioncorr-peakfit/build-cuda -j8 --target cuda_peak_fit cuda_peak_fit_float_denominator 
