
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     1.060000   300.000000     2.700000     0.100000     1.060000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographName #1 
_rlnMicrographMetadata #2 
_rlnOpticsGroup #3 
_rlnAccumMotionTotal #4 
_rlnAccumMotionEarly #5 
_rlnAccumMotionLate #6 
/mnt/clathrin/alex-motioncorr-peakfit/runs/e10474f3-06-p3-Nnative1/Movies/2019-06-21_23-43-39_840_eer_data_4096x4096.mrc /mnt/clathrin/alex-motioncorr-peakfit/runs/e10474f3-06-p3-Nnative1/Movies/2019-06-21_23-43-39_840_eer_data_4096x4096.star            1    13.300217     0.566125    12.734093 
 
