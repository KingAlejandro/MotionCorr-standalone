
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     0.885000   200.000000     1.400000     0.100000     0.885000 
"optics group two"            2     1.070000   300.000000     2.700000     0.070000     1.070000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographName #1 
_rlnMicrographMetadata #2 
_rlnOpticsGroup #3 
_rlnAccumMotionTotal #4 
_rlnAccumMotionEarly #5 
_rlnAccumMotionLate #6 
sharded/w0/Movies/mov_00.mrc sharded/w0/Movies/mov_00.star            1     6.203727     4.236177     1.967550 
sharded/w0/Movies/mov_01.mrc sharded/w0/Movies/mov_01.star            1     6.203727     2.150435     4.053292 
 
