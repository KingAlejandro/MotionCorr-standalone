
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     0.517000   300.000000     2.700000     0.100000     0.517000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographName #1 
_rlnMicrographMetadata #2 
_rlnOpticsGroup #3 
_rlnAccumMotionTotal #4 
_rlnAccumMotionEarly #5 
_rlnAccumMotionLate #6 
/mnt/clathrin/alex-motioncorr-s1/sweep/runs/e10216-03-p3-F-cpu/Movies/FoilHole_14962024_Data_14966722_14966723_20180616_0825_Fractions.mrc /mnt/clathrin/alex-motioncorr-s1/sweep/runs/e10216-03-p3-F-cpu/Movies/FoilHole_14962024_Data_14966722_14966723_20180616_0825_Fractions.star            1    59.558010    21.019179    38.538831 
 
