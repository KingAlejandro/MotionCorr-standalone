/home/alex/.mc-venv/bin/python3 /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/tools-v2-run/c1_tutorial24.py compare /t24/N-L/out /t24/c1-L/out N_vs_c1-L 
