#!/bin/bash
# SPDX-License-Identifier: GPL-2.0-or-later
# gpu-devel QOS MaxSubmitJobsPerUser=1; retain failed submissions, then serialize.
set -u
W=$HOME/mc-post-rc0-s1
exec 9>"$W/followon.lock"
flock -n 9 || exit 75
while [ ! -f "$W/launch-a2/exit" ] || squeue -h -j "$(cat "$W/launch-a2/job.id")" 2>/dev/null | grep -q .; do sleep 15; done
rc=$(cat "$W/launch-a2/exit")
echo "$rc" > "$W/followon-prior.exit"
bash "$W/tools/scarf_launch_v2.sh" b3 e10441,e10474f4,e10164
rc=$?
echo "$rc" > "$W/followon.exit"
exit "$rc"
