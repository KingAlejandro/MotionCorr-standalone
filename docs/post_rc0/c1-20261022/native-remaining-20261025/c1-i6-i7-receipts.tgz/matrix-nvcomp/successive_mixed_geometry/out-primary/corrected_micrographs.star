
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     1.400000   300.000000     2.700000     0.100000     1.400000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographName #1 
_rlnMicrographMetadata #2 
_rlnOpticsGroup #3 
_rlnAccumMotionTotal #4 
_rlnAccumMotionEarly #5 
_rlnAccumMotionLate #6 
/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/matrix-nvcomp/successive_mixed_geometry/out-primary/Movies/mov00_g1_64x48x6.mrc /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/matrix-nvcomp/successive_mixed_geometry/out-primary/Movies/mov00_g1_64x48x6.star            1    10.211797     6.603115     3.608682 
/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/matrix-nvcomp/successive_mixed_geometry/out-primary/Movies/mov01_g2_54x72x8.mrc /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/matrix-nvcomp/successive_mixed_geometry/out-primary/Movies/mov01_g2_54x72x8.star            1    14.985394     6.321574     8.663819 
/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/matrix-nvcomp/successive_mixed_geometry/out-primary/Movies/mov02_g1_64x48x6.mrc /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/matrix-nvcomp/successive_mixed_geometry/out-primary/Movies/mov02_g1_64x48x6.star            1    10.211797     6.603115     3.608682 
 
