#!/usr/bin/env python3
"""Host controls for c1_ingest_poison.py's verdict functions (no GPU): a faithful synthetic faulted run must PASS fault_verdict, and each single-requirement
mutation of it must be rejected; healthy/notarget synthetic runs must pass their own verdicts and be rejected by fault_verdict. usage: python3 test_c1_ingest_poison.py"""
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import c1_ingest_poison as d  # noqa: E402

ARM_LOG = ("ERROR: the CUDA context became unusable during device ingestion of Movies/control.tiff; refusing to report a successful ingest.\n")
CONSOLE = (
    "[ingeststicky] gain-launch index=0\n"
    "[ingeststicky] gain-launch index=1\n"
    "[ingeststicky] launch illegal write before ingest gain launch 1\n"
    "[ingeststicky] fault completion=700 (an illegal memory access was encountered)\n"
    "[ingeststicky] product launch result=700 (an illegal memory access was encountered), unchanged\n"
    "The CUDA context became unusable during device ingestion of Movies/control.tiff. Refusing any fallback after a fatal device error.\n"
    "Motion correction failed for 3 movie(s): Movies/control.tiff Movies/after1.tiff Movies/after2.tiff. "
    "Successful per-movie outputs were retained; joint output was not generated.\n"
    "[ingeststicky] exit gain-launches=2 faulted=1\n")


def healthy_console(n):
    return ''.join(f'[ingeststicky] gain-launch index={i}\n' for i in range(3 * n))


class Controls(unittest.TestCase):
    def out(self, files=('Movies/control.log',)):
        t = Path(tempfile.mkdtemp())
        for f in files:
            (t / f).parent.mkdir(parents=True, exist_ok=True)
            (t / f).write_text(ARM_LOG if f.endswith('.log') else 'x')
        return t

    def verdict(self, console=CONSOLE, rc=1, files=('Movies/control.log',), witness='', count=3):
        d.fault_verdict(rc, console, self.out(files), count, witness)

    def test_faithful_passes(self):
        self.verdict()
        self.verdict(witness='Movies/control.tiff nvcomp\n')

    def rejects(self, **kw):
        with self.assertRaises(d.Reject):
            self.verdict(**kw)

    def test_each_mutation_is_rejected(self):
        self.rejects(console=CONSOLE.replace('launch illegal write before ingest gain launch 1', 'launch illegal write before ingest gain launch 2'))
        self.rejects(console=CONSOLE.replace('[ingeststicky] launch illegal write before ingest gain launch 1\n', ''))
        self.rejects(console=CONSOLE.replace('[ingeststicky] launch illegal write before ingest gain launch 1\n',
                                             '[ingeststicky] launch illegal write before ingest gain launch 1\n' * 2))
        self.rejects(console=CONSOLE.replace('completion=700 ', 'completion=0 '))
        self.rejects(console=CONSOLE.replace('product launch result=700 ', 'product launch result=0 '))
        self.rejects(rc=0)
        self.rejects(rc=2)
        self.rejects(console=CONSOLE.replace('Refusing any fallback after a fatal device error', 'Refusing'))
        self.rejects(console=CONSOLE.replace('Movies/control.tiff. Refusing', 'Movies/other.tiff. Refusing'),
                     files=())      # no attribution to control.tiff anywhere (ARM_LOG in a log would also satisfy it)
        self.rejects(console=CONSOLE + 'Device ingestion failed recoverably for Movies/control.tiff; re-reading the movie with the host reader.\n')
        self.rejects(console=CONSOLE + 'Staging this movie as native unsigned 16-bit\n')
        self.rejects(witness='Movies/control.tiff compact\n')
        self.rejects(console=CONSOLE.replace('Movies/after2.tiff.', '.').replace('3 movie(s): Movies/control.tiff Movies/after1.tiff ', '3 movie(s): Movies/control.tiff Movies/after1.tiff'))
        self.rejects(console=CONSOLE.replace('Motion correction failed for 3 movie(s)', 'Motion correction failed for 2 movie(s)'))
        self.rejects(console=CONSOLE.replace('Motion correction failed for', 'Failure for'))
        self.rejects(console=CONSOLE + '[ingeststicky] PRODUCT_KERNEL_AFTER_FAULT\n')
        self.rejects(console=CONSOLE.replace('[ingeststicky] gain-launch index=1\n', ''))
        self.rejects(console=CONSOLE + '[ingeststicky] gain-launch index=2\n')
        self.rejects(files=('Movies/control.log', 'Movies/control.mrc'))
        self.rejects(files=('Movies/control.log', 'corrected_micrographs.star'))

    def test_healthy_and_notarget_runs_are_rejected_by_the_fault_verdict(self):
        out = self.out(('Movies/control.log', 'Movies/control.mrc'))
        for console in (healthy_console(3), ''):
            with self.assertRaises(d.Reject):
                d.fault_verdict(0, console, out, 3, 'Movies/control.tiff nvcomp\n')

    def test_healthy_verdicts(self):
        t = Path(tempfile.mkdtemp())
        for m in d.MOVIES:
            for ext in ('mrc', 'star'):
                (t / 'Movies').mkdir(exist_ok=True)
                (t / 'Movies' / f'{Path(m).stem}.{ext}').write_text('x')
        (t / 'corrected_micrographs.star').write_text('x')
        w = ''.join(f'{m} nvcomp\n' for m in d.MOVIES)
        d.ingest_healthy_verdict(0, healthy_console(3), t, 3, w)
        with self.assertRaises(d.Reject): d.ingest_healthy_verdict(0, healthy_console(3), t, 3, w.replace('nvcomp', 'float', 1))
        with self.assertRaises(d.Reject): d.ingest_healthy_verdict(0, healthy_console(2), t, 3, w)
        with self.assertRaises(d.Reject): d.ingest_healthy_verdict(1, healthy_console(3), t, 3, w)
        d.notarget_verdict(0, '', t, 3, ''.join(f'{m} float\n' for m in d.MOVIES))
        with self.assertRaises(d.Reject): d.notarget_verdict(0, healthy_console(1), t, 3, '')     # ingest was entered
        with self.assertRaises(d.Reject): d.notarget_verdict(0, '', t, 3, w)                       # witness nvcomp

    def test_expect_reject_helper_discriminates(self):
        out = self.out(('Movies/control.log',))
        self.assertEqual(d.expect_reject('x', d.fault_verdict, 0, healthy_console(3), out, 3, '')['verdict'], 'PASS')
        self.assertEqual(d.expect_reject('x', d.fault_verdict, 1, CONSOLE, out, 3, '')['verdict'], 'FAIL')    # a faithful run is NOT rejected -> control FAIL


if __name__ == '__main__':
    unittest.main(verbosity=2)
