import json,os,pathlib,subprocess,time
root=pathlib.Path('/home/ubuntu/mc-km-truth-20261021'); os.chdir(root)
import sys
sys.path[:0]=[str(root/'v2/test-data'),str(root/'deps')]
import generate_realistic_motion as gen
(root/'fixtures').mkdir(exist_ok=True)
conditions=['dose1','dose05','dose2','dose4','outmodel','nonsquare','pedestal0','pedestal32','contrast025','contrast4']
for condition in conditions:
 r=gen.recipe(condition)
 key='outmodel' if condition=='outmodel' else ('nonsquare' if condition=='nonsquare' else 'inmodel')
 expect=root/'expectations'/(key+'.npy')
 if not expect.with_suffix('.json').exists():
  if expect.exists(): raise RuntimeError('incomplete expectation remains')
  proof=gen.expected(r,expect)
  expect.with_suffix('.json').write_text(json.dumps(dict(recipe=r,proof=proof),indent=2)+'\n')
 for seed in range(10):
  name=f'{condition}-s{seed:02d}'; dest=root/'fixtures'/name
  # Keep cpu64 headroom; release only a hash-verified duplicate after CPU completion
  # and external GPU-copy acknowledgement. Original remains on 4GPUs.
  while True:
   for p in (root/'fixtures').glob('*/movie.mrcs'):
    if (p.parent/'GPU_COPY_VERIFIED.json').exists() and (root/'results'/p.parent.name/'cpu.done.json').exists():
     receipt=json.loads((p.parent/'RECEIPT.json').read_text())
     if gen.digest(p)!=receipt['files']['movie.mrcs']: raise RuntimeError('cleanup input changed')
     p.unlink()
   if __import__('shutil').disk_usage(root).free > 35*(1<<30): break
   time.sleep(15)
  if dest.exists(): raise RuntimeError('fixture already exists')
  start=time.time(); gen.generate(gen.recipe(condition,seed),expect,dest)
  print(name,'generated',time.time()-start,flush=True)
(root/'generation.done').write_text('100 fixtures generated\n')
