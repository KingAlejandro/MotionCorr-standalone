#!/bin/bash
# Build the genuine nvCOMP-ingest fault binary out of tree: the tested build's run_motioncorr.cpp.o and libmotioncorr_core.a (d7c4e2e3 build of e77a51a2,
# read in place) plus the test-only interposer; no CMake or production-source change. Link line = build-nvcomp's link.txt with -rdynamic, --wrap=cudaLaunchKernel
# and the interposer object added. usage: c1_ingest_build.sh   (compiles one .cu file: allowed under the build lock, 2 compile jobs at most)
set -u
D=$(cd "$(dirname "$0")" && pwd); source "$D/c1_env.sh" || exit 1
exec 8>>$C1_BUILD_LOCK; flock -n 8 || { echo "build lock contended; stopping"; exit 5; }
NB=$C1_BUILDS_SRC/build-nvcomp; B=$C1_SCR/build-ingest-fault; mkdir -p $B
sha256sum $NB/motioncorr $NB/libmotioncorr_core.a $NB/CMakeFiles/motioncorr.dir/src/apps/run_motioncorr.cpp.o $D/cuda_ingest_sticky_fault.cu > $B/inputs.sha256
nvcc -O3 -DNDEBUG -std=c++17 "--generate-code=arch=compute_80,code=[compute_80,sm_80]" -D_CUDA_ENABLED -D_NVCOMP_ENABLED \
  -I$C1_BUILDS_SRC/src -I$C1_NVCOMP/include -c $D/cuda_ingest_sticky_fault.cu -o $B/cuda_ingest_sticky_fault.o || exit 2
cd $NB
link=$(cat CMakeFiles/motioncorr.dir/link.txt)
link=${link/\/usr\/bin\/c++ -O3 -DNDEBUG /\/usr\/bin\/c++ -O3 -DNDEBUG -rdynamic -Wl,--wrap=cudaLaunchKernel }
link=${link/CMakeFiles\/motioncorr.dir\/src\/apps\/run_motioncorr.cpp.o -o motioncorr/CMakeFiles\/motioncorr.dir\/src\/apps\/run_motioncorr.cpp.o $B\/cuda_ingest_sticky_fault.o -o $B\/motioncorr_ingest_fault}
echo "$link" > $B/link.cmd
bash -c "$link" || exit 3
sha256sum $B/motioncorr_ingest_fault > $B/binary.sha256; cat $B/binary.sha256
