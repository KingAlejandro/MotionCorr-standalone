
import os,json,hashlib,subprocess,fcntl,time,socket,sys
from pathlib import Path
S=Path(__file__).resolve().parent; R=S.parent.parent
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return h.hexdigest()
def put(n,j):
 with (S/n).open('x') as f:json.dump(j,f,indent=1);f.write('\n')
me=os.getpid();put('worker-start.json',{'utc':time.strftime('%FT%TZ',time.gmtime()),'pid':me,'uid':os.getuid(),'host':socket.gethostname(),'stat':Path('/proc/self/stat').read_text(),'status':Path('/proc/self/status').read_text(),'argv':sys.argv,'env':{k:os.environ.get(k) for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','CUDA_VISIBLE_DEVICES']}})
rc=1
try:
 with open('/tmp/motioncorr-dc-eval-cpu13.lock','a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  assert os.sched_getaffinity(0)=={13}
  m=json.loads((S/'SNAPSHOT.json').read_text())
  assert sha(R/'tools/evaluate.py')==m['evaluator_sha256']
  for p,h in m['source_python_sha256'].items():assert sha(R/'src'/p)==h,p
  verified=[]
  for rid,j in m['records'].items():
   run=R/'runs'/rid
   assert sha(run/'RUN.json')==j['record_sha256'],rid
   rec=json.loads((S/'runs'/rid/'RUN.json').read_text())
   assert sha(Path(rec['cwd'])/'RECEIPT.json')==rec['inputs'][str(Path(rec['cwd'])/'RECEIPT.json')]
   if rec['exit']==0 and rec['arm']!='plain':
    for rel in ['runtime.json','output/movie.star','output/movie.log','output/movie.mrc']:
     meta=rec['outputs'][rel]; p=run/rel
     assert p.stat().st_size==meta['bytes'] and sha(p)==meta['sha256'],(rid,rel)
   verified.append(rid)
  put('INPUT_VERIFICATION.json',{'utc':time.strftime('%FT%TZ',time.gmtime()),'records':len(verified),'ids':verified,'read_only_original':True,'scope':'Current RUN bytes, fixture receipts, evaluator/imported-source hashes and all evaluator-consumed output hashes verified; original movie stacks not rehashed; cached evaluations reused as retained evidence.'})
  assert sum(p.stat().st_size for p in S.rglob('*') if p.is_file() and not p.is_symlink())<512*(1<<20)
  with (S/'evaluate.out').open('x') as out:
   cmd=[sys.executable,'-B',str(R/'tools/evaluate.py'),'B',str(S)]
   put('evaluate-command.json',{'argv':cmd,'cwd':str(S),'cpu':[13],'numeric_threads':1,'gpu':False,'timing_qualified':False})
   p=subprocess.Popen(cmd,cwd=S,stdout=out,stderr=subprocess.STDOUT)
   put('evaluate-child.json',{'pid':p.pid,'stat':Path(f'/proc/{p.pid}/stat').read_text(),'status':Path(f'/proc/{p.pid}/status').read_text()})
   rc=p.wait()
  if rc==0:
   got={p.stem:sha(p) for p in (S/'eval/B').glob('*.json')}
   assert set(got)==set(m['records'])
   for rid,h in m['retained_evaluations'].items():assert got[rid]==h
   for rid,j in m['records'].items():assert sha(R/'runs'/rid/'RUN.json')==j['record_sha256']
   put('EVALUATIONS.json',{'count':len(got),'reused':len(m['retained_evaluations']),'new':len(got)-len(m['retained_evaluations']),'sha256':got,'aggregate':'Partial frozen TierB snapshot only; native campaign and GPU/C science incomplete; cost UNRUN.'})
except BaseException as e:
 put('ERROR.json',{'type':type(e).__name__,'message':str(e)});rc=1
finally:
 put('worker-exit.json',{'exit':rc,'utc':time.strftime('%FT%TZ',time.gmtime()),'scope':'Analysis only. No new native run or scientific qualification.'})
sys.exit(rc)
