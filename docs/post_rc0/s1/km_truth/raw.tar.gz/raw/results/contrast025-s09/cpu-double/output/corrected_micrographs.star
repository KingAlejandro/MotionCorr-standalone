
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     0.885000   300.000000     2.700000     0.100000     0.885000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographName #1 
_rlnMicrographMetadata #2 
_rlnOpticsGroup #3 
_rlnAccumMotionTotal #4 
_rlnAccumMotionEarly #5 
_rlnAccumMotionLate #6 
/home/ubuntu/mc-km-truth-20261021/results/contrast025-s09/cpu-double/output/movie.mrc /home/ubuntu/mc-km-truth-20261021/results/contrast025-s09/cpu-double/output/movie.star            1    14.415179     5.108009     9.307171 
 
