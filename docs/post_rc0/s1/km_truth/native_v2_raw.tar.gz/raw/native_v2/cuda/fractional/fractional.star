
# version 50001

data_general

_rlnImageSizeX                                      128
_rlnImageSizeY                                       96
_rlnImageSizeZ                                        5
_rlnMicrographMovieName                    fractional.mrcs
_rlnMicrographBinning                          1.000000
_rlnMicrographOriginalPixelSize                0.885000
_rlnMicrographDoseRate                         1.000000
_rlnMicrographPreExposure                      0.000000
_rlnVoltage                                  300.000000
_rlnMicrographStartFrame                              1
_rlnMotionModelVersion                                0
 

# version 50001

data_global_shift

loop_ 
_rlnMicrographFrameNumber #1 
_rlnMicrographShiftX #2 
_rlnMicrographShiftY #3 
           1     0.000000     0.000000 
           2     -1.06250     1.000000 
           3     -1.77083     1.250000 
           4     -2.47917     1.500000 
           5     -3.54167     2.500000 
 
