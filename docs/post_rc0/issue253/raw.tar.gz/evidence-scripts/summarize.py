#!/usr/bin/env python3
import csv,hashlib,json,pathlib,re,tarfile,xml.etree.ElementTree as ET
S=pathlib.Path('/tmp/motioncorr-253'); D=pathlib.Path('docs/post_rc0/issue253'); D.mkdir(exist_ok=True)
N=S/'native'; P=S/'products'; A=S/'analysis'; Q=S/'qf'
base='3691374061f782bc84531fd1c79d017ddcb5a7c2'; implementation='e539660cc6fc56e32ad29ef25ee28dee3e0dcbbc'; candidate=(N/'source-final.txt').read_text().strip()
assert candidate=='adf990fd9801e1124814e3c4fcb30a3a7fd8ff42'
assert not (N/'source-final.status').read_text().strip()
ctest={}
for cfg,count in [('cpu',74),('cuda',110),('nvcomp',113)]:
 root=ET.parse(N/f'ctest-{cfg}.xml').getroot(); a=root.attrib
 assert int(a['tests'])==count and int(a['failures'])==0 and int(a['skipped'])==0
 assert (N/f'ctest-{cfg}.exit').read_text().strip()=='0'
 ctest[cfg]=dict(tests=count,passed=count,failed=0,skipped=0,source=implementation if cfg=='cpu' else candidate,**{k:a[k] for k in ['hostname','timestamp']})
exits={}
for name,rc in [('inverse-main',1),('inverse-fixed',0),('inverse-mutant',1),('inverse-mutant-expected',0),('matrix-cuda',0),('matrix-nvcomp',0),('collection-cpu',0),('collection-cuda',0),('collection-nvcomp',0)]:
 exits[name]=int((N/f'{name}.exit').read_text());assert exits[name]==rc,(name,exits[name])
rows=[]
for line in (N/'inverse-fixed.log').read_text().splitlines():
 if re.match(r'(session|wrapper|dose|raw_planmany)',line):
  x=line.split();rows.append(dict(path=x[0],**{k:float(v) for k,v in (t.split('=') for t in x[1:-1])},status=x[-1]))
assert all(x['status']=='PASS' for x in rows if not x['path'].startswith('raw_'))
with (D/'inverse-matrix.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
matrices={}
for cfg in ['cuda','nvcomp']:
 data=json.loads((Q/f'matrix-{cfg}.json').read_text());assert data['summary']==dict(selected=16,passed=16,failed=0)
 assert data['source_commit']==candidate and data['source_modified_files']==0
 matrices[cfg]=dict(**data['summary'],arms=sum(len(c.get('arms',{})) for c in data['cases']),source=data['source_commit'])
summary=json.loads((A/'products-summary.json').read_text());product_rows=[];commands={}
for label in ['main-cpu-G','main-cpu-L','main-cuda-G','main-cuda-L','fixed-cpu-G','fixed-cpu-L','fixed-cuda-G','fixed-cuda-L']:
 c=json.loads((P/label/'command.json').read_text()); assert c['exit_status']==0 and c['actual_cpu_affinity']==list(range(88,96))
 if '-cuda-' in label:
  assert c['gpu_observed_uuids']==['GPU-b2cb2c39-8524-17fb-73a8-80cd61dbf83d']
  log=next((P/label/'Movies').glob('*.log')).read_text()
  for marker in ['Reconstructing globally aligned frames (CUDA in-VRAM)', 'Dose weighting and summing frames (CUDA in-VRAM)', 'CUDA Dose-Weighted Reconstruction Profile (Resident VRAM)']:
   assert marker in log,(label,marker)
  assert not any(marker in log for marker in ['CUDA Error','cuFFT Error','Falling back','falling back'])
 commands[label]=c
for name in ['CPU-control-G','CPU-control-L']:
 r=summary[name];assert r['STAR']['equal'] and r['STAR']['bytes_identical']
 for k in ['DW','nonDW']:
  assert r[k]['pixels_identical'] and r[k]['core_header_identical'] and r[k]['labels_equal_after_date_normalization']
for source in ['main','fixed']:
 for cfg in ['G','L']:
  r=summary[f'{source}-{cfg}'];row=dict(source=source,config=cfg,nonDW_relative_rmse=r['nonDW']['image']['relative_rmse'],DW_relative_rmse=r['DW']['image']['relative_rmse'],backend_nonDW=r['nonDW']['overall_status'],backend_DW=r['DW']['overall_status'])
  m=r['local_model'];row.update(model_coeff_relative_rmse=m['serialized_coefficients']['relative_rmse'] if m else '',model_field_relative_rmse=m['evaluated_field']['relative_rmse'] if m else '',model_field_rmse_px=m['evaluated_field']['rmse'] if m else '',model_field_max_abs_px=m['evaluated_field']['max_abs'] if m else '')
  product_rows.append(row)
  for prod in ['DW','nonDW']:
   full=json.loads((A/f'{source}-{cfg}-{prod}.json').read_text());assert full['coverage']['complete'] and full['checks']['corrected_image']['num_pixels']==4096**2
with (D/'products.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(product_rows[0]));w.writeheader();w.writerows(product_rows)
(D/'products-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
record=dict(record_integrity_status='PASS',base_sha=base,implementation_sha=implementation,candidate_sha=candidate,ctest=ctest,exit_statuses=exits,compact_matrices=matrices,product_runs=len(commands),all_product_exits_zero=True,cpu_products_identical=True,gpu_uuid='GPU-b2cb2c39-8524-17fb-73a8-80cd61dbf83d',cpu_affinity=list(range(88,96)),input=json.loads((P/'input.json').read_text()),build_configs=json.loads((N/'build-configs.json').read_text()),products=product_rows,notes=['CPU full CTest was on e539660c; adf990fd changes only the CUDA test oracle. CPU production/build sources are identical.', 'Backend gate statuses are records only; no thresholds overridden.', 'Model metrics use published STAR coefficients; field evaluates z=0..58 on the normalized 21x21 square [-0.5,0.5]^2.', 'Raw PlanMany batch-two rows sample its first output frame; production full-frame batch-one execution checks both resident frames.'])
(D/'validation.json').write_text(json.dumps(record,indent=2)+'\n')
# Retain text/JSON/XML records only; no movies, images, libraries or executables.
files=[]
for sub in ['native','analysis','products','qf','evidence-scripts']:
 for p in sorted((S/sub).rglob('*')):
  if p.is_file() and not p.is_symlink() and p.suffix in ['.json','.log','.exit','.xml','.txt','.csv','.star','.sha256','.sh','.py','.status']:
   files.append(p)
index=[]
with tarfile.open(D/'raw.tar.gz','w:gz') as tar:
 for p in files:
  rel=p.relative_to(S);blob=p.read_bytes(); index.append(dict(path=str(rel),bytes=len(blob),sha256=hashlib.sha256(blob).hexdigest()));tar.add(p,arcname=str(rel),recursive=False)
(D/'raw-index.json').write_text(json.dumps(index,indent=2)+'\n')
print(json.dumps(dict(status='PASS',ctest=ctest,matrices=matrices,product_runs=8,raw_files=len(files),raw_archive_bytes=(D/'raw.tar.gz').stat().st_size),indent=2))
