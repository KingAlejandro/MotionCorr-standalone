#!/bin/bash
# One-off orchestration (hash recorded): attribution builds, then full CTest x3 and grading, strictly sequential on CPUs 8-9 / GPU3.
export C1_SCR=/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb C1_SHA=e77a51a220cb0d91f4ac3c7fac211876d0c6833f
T=/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/src/docs/post_rc0/c1-20261022/tools
cd /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb
until [ -f logs/build-cuda.exit ]; do sleep 5; done
for a in N only254 only260 only270; do bash $T/c1_stage.sh attr-$a bash $T/c1_attr_build.sh $a; done
for cfg in cpu cuda nvcomp; do
  bash $T/c1_stage.sh ctest-$cfg bash $T/c1_ctest.sh $cfg
  bash $T/c1_stage.sh grade-$cfg /home/alex/.mc-venv/bin/python3 $T/c1_grade_ctest.py $cfg
done
echo chain-done > logs/chain-2.done
