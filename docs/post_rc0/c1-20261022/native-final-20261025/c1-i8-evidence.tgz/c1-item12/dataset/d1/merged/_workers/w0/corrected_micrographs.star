
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroupTut            1     0.885000   200.000000     1.400000     0.100000     0.885000 
opticsGroup10641            2     0.400000   300.000000     2.700000     0.100000     0.400000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographName #1 
_rlnMicrographMetadata #2 
_rlnOpticsGroup #3 
_rlnAccumMotionTotal #4 
_rlnAccumMotionEarly #5 
_rlnAccumMotionLate #6 
/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb-i8-20261025/c1-item12/dataset/d1/workers/w0/Movies/20170629_00026_frameImage.mrc /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb-i8-20261025/c1-item12/dataset/d1/workers/w0/Movies/20170629_00026_frameImage.star            1    10.202249     2.048605     8.153644 
/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb-i8-20261025/c1-item12/dataset/d1/workers/w0/Movies/HM70-1_10-A-002_0002_Oct28_23_00_41.mrc /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb-i8-20261025/c1-item12/dataset/d1/workers/w0/Movies/HM70-1_10-A-002_0002_Oct28_23_00_41.star            2    81.185515    12.659731    68.525784 
/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb-i8-20261025/c1-item12/dataset/d1/workers/w0/Movies/20170629_00031_frameImage.mrc /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb-i8-20261025/c1-item12/dataset/d1/workers/w0/Movies/20170629_00031_frameImage.star            1    11.249237     2.086097     9.163140 
/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb-i8-20261025/c1-item12/dataset/d1/workers/w0/Movies/HM70-1_10-A-004_0008_Oct28_23_06_04.mrc /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb-i8-20261025/c1-item12/dataset/d1/workers/w0/Movies/HM70-1_10-A-004_0008_Oct28_23_06_04.star            2    61.401391     4.383558    57.017833 
 
