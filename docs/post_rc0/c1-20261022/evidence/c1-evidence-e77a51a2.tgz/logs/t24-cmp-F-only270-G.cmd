/home/alex/.mc-venv/bin/python3 /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/tools-v2-run/c1_tutorial24.py compare /t24/F-fresh-G/out /t24/only270-G/out F-fresh_vs_only270-G 
