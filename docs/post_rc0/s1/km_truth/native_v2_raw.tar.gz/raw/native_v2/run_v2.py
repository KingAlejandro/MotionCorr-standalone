import json, os, pathlib, subprocess, sys, time
root=pathlib.Path(sys.argv[1]); backend=sys.argv[2]; binary=root/'main-build/motioncorr'; fixtures=root/'v2/fixtures'; out=root/'v2'/backend; out.mkdir(exist_ok=False)
rows=[]
for name in ['zero','integer','fractional','affine','pedestal','noisy','flat','repeated']:
 p=3 if name in ['affine','pedestal','noisy'] else 1
 cmd=['taskset','-c', '96-103' if backend=='cuda' else '40-47',str(binary),'--i',name+'.star','--o',str(out/name),'--use_own','--j','8','--patch_x',str(p),'--patch_y',str(p),'--bin_factor','1','--seed','1','--skip_defect','--save_noDW','--first_frame_sum','1','--last_frame_sum','5','--skip_logfile']
 if backend=='cuda': cmd += ['--gpu','0']
 env=os.environ.copy(); env['OMP_NUM_THREADS']='8'
 if backend=='cuda': env['CUDA_VISIBLE_DEVICES']='GPU-063e5232-7fc5-f1e6-7a0d-260577c4e598'
 start=time.time()
 with (out/(name+'.stdout')).open('w') as f: rc=subprocess.run(cmd,cwd=fixtures,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 rows.append(dict(case=name,backend=backend,patches=p,argv=cmd,exit=rc,seconds=time.time()-start))
 (out/'runs.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(name,rc,flush=True)
