#!/bin/bash
# C1 iteration 2 (T24 + truth + recovery), frozen before launch. Tested source e77a51a2 (exact checkout, existing binaries); tools packet 1aac4159 at tools-v2.2-run.
# Every stage is a c1_stage.sh stage (exclusive name, PID/exit receipts). The chain STOPS at the first stage whose exit is not in its allowed set and writes
# logs/chain-i2.stop. Allowed exits: lane-identity and N-vs-C1 comparisons only 0 (IDENTICAL); other comparisons 0 or 1 (valid IDENTICAL/DIFFERENT; 2 = INVALID stops);
# runs, datasets, truth drivers, recovery rows and health only 0. No in-place retry; nothing is repeated.
SC=/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb
export C1_SCR=$SC C1_SHA=e77a51a220cb0d91f4ac3c7fac211876d0c6833f C1_T24_DIR=t24-i2
V=$SC/tools-v2.2-run; PY=/home/alex/.mc-venv/bin/python3; F=/mnt/clathrin/alex-motioncorr-rc0/W-QF; T=$SC/t24-i2; SP=/mnt/clathrin/alex-motioncorr-synth-combined
SCIPY=$SP/venv/bin/python3
cd $SC
until [ -f logs/chain-3.done ]; do sleep 10; done          # iteration-1 CPU baselines finish first (CPUs 8-9 are shared)
echo $$ > logs/chain-i2.pid; date -u +%FT%TZ > logs/chain-i2.started
go() { n=$1; ok=$2; shift 2; bash $V/c1_stage.sh "$n" "$@"; rc=$?
  case " $ok " in *" $rc "*) return 0;; esac
  { echo "stage $n exited $rc (allowed: $ok)"; date -u +%FT%TZ; } > logs/chain-i2.stop; exit 1; }
declare -A BIN=( [F-fresh]=$F/build-nvcomp/motioncorr [N]=$SC/attr/N/build/motioncorr [only254]=$SC/attr/only254/build/motioncorr [only260]=$SC/attr/only260/build/motioncorr [only270]=$SC/attr/only270/build/motioncorr [c1]=$SC/build-nvcomp/motioncorr )
for cfg in G L; do
  go i2-run-F-fresh-$cfg 0 $PY $V/c1_tutorial24.py run F-fresh ${BIN[F-fresh]} $cfg
  go i2-cmp-lane-$cfg 0 $PY $V/c1_tutorial24.py compare $F/multigpu/$cfg/s0 $T/F-fresh-$cfg/out F-fresh_vs_F-retained-$cfg
  for a in c1 N only254 only260 only270; do
    go i2-run-$a-$cfg 0 $PY $V/c1_tutorial24.py run $a ${BIN[$a]} $cfg
    go i2-cmp-F-$a-$cfg "0 1" $PY $V/c1_tutorial24.py compare $T/F-fresh-$cfg/out $T/$a-$cfg/out F-fresh_vs_$a-$cfg
  done
  go i2-cmp-N-c1-$cfg 0 $PY $V/c1_tutorial24.py compare $T/N-$cfg/out $T/c1-$cfg/out N_vs_c1-$cfg
  for a in only254 only260 only270; do go i2-cmp-$a-c1-$cfg "0 1" $PY $V/c1_tutorial24.py compare $T/$a-$cfg/out $T/c1-$cfg/out ${a}_vs_c1-$cfg; done
  go i2-attribute-$cfg 0 $PY $V/c1_tutorial24.py attribute $cfg
done
for cfg in G L; do go i2-dataset-c1-$cfg 0 bash $V/c1_gpu_run.sh i2-ds-$cfg $PY $V/c1_tutorial24.py dataset c1 ${BIN[c1]} $cfg; done
go i2-v2-cpu 0 bash $V/c1_v2.sh cpu
go i2-v2-cuda 0 bash $V/c1_v2.sh cuda
go i2-r12 0 bash $V/c1_item.sh 12
go i2-r12ds 0 bash $V/c1_item.sh 12ds
go i2-r9-cuda 0 bash $V/c1_item.sh 9cuda
go i2-r9-nvcomp 0 bash $V/c1_item.sh 9nvcomp
go i2-census-cuda 0 bash $V/c1_gpu_run.sh i2-census-cuda $PY $V/c1_census.py run cuda ${BIN[c1]} results-c1-cuda
go i2-census-cmp-cuda 0 $PY $V/c1_census.py compare results-c1-cuda $SP/results-plain270 cuda-none cuda $SC/census-cuda-vs-plain270.json
go i2-census-cmp-cuda-check 0 $PY -c "import json,sys;s=json.load(open('$SC/census-cuda-vs-plain270.json'))['summary'];print(s);sys.exit(0 if s['n']==100 and s['errors']==0 and s['nonzero_exit']==0 and s['sum_equal']==100 and s['star_equal']==100 else 1)"
go i2-census-metrics-cuda 0 $PY $V/c1_census.py metrics results-c1-cuda cuda $SC/census-cuda-metrics.json
for cfg in G L; do
  go i2-check-Fcpu-$cfg 0 grep -q '"rc": 0' $SC/t24/F-cpu-$cfg/RUN.json
  go i2-run-c1-cpu-$cfg 0 $PY $V/c1_tutorial24.py run c1-cpu $SC/build-cpu/motioncorr $cfg --cpu
  go i2-cmp-cpu-$cfg 0 $PY $V/c1_tutorial24.py compare $SC/t24/F-cpu-$cfg/out $T/c1-cpu-$cfg/out F-cpu_vs_c1-cpu-$cfg
done
go i2-census-cpu 0 $PY $V/c1_census.py run cpu $SC/build-cpu/motioncorr results-c1-cpu
go i2-census-metrics-cpu 0 $PY $V/c1_census.py metrics results-c1-cpu cpu $SC/census-cpu-metrics.json
go i2-image-cuda 0 env OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 $SCIPY $SC/src/docs/post_rc0/s1/synth_combined/image_batch.py eval $SC/census results-c1-cuda x 2
date -u +%FT%TZ > logs/chain-i2.finished; echo chain-done > logs/chain-i2.done
