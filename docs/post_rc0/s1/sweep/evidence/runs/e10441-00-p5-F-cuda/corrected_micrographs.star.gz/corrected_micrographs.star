
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     0.568500   200.000000     2.700000     0.100000     0.568500 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographName #1 
_rlnMicrographMetadata #2 
_rlnOpticsGroup #3 
_rlnAccumMotionTotal #4 
_rlnAccumMotionEarly #5 
_rlnAccumMotionLate #6 
/mnt/clathrin/alex-motioncorr-s1/sweep/runs/e10441-00-p5-F-cuda/Movies/20May09_3A-3_109-21_0003.mrc /mnt/clathrin/alex-motioncorr-s1/sweep/runs/e10441-00-p5-F-cuda/Movies/20May09_3A-3_109-21_0003.star            1    16.548697     2.908297    13.640400 
 
