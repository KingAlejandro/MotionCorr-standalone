import os,signal,time,json
from pathlib import Path
r=Path('/mnt/clathrin/alex-motioncorr-s1/sweep')
lanes=[dict(index=i,uuid=u,cpus='96-103') for i,u in [(3,'GPU-b2cb2c39-8524-17fb-73a8-80cd61dbf83d'),(0,'GPU-eddb42fe-4f9a-adde-76d3-b924e14add54'),(2,'GPU-063e5232-7fc5-f1e6-7a0d-260577c4e598'),(1,'GPU-cd5b9f86-26e6-0a03-bdd2-effcfa0fe42d')]]
config=dict(lanes[0],fallback_lanes=lanes[1:],reason='select an available locked lane before payload start',set_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
(r/'lane.json').write_text(json.dumps(config,indent=2)+'\n')
items=[(1831303,1964918,'e10028-06-p3-F-cpu'),(1914862,1964897,'e10216-00-p5-f6c41e24-cuda')]
records=[]
for parent,arm,label in items:
 try:
  assert label.encode() in Path(f'/proc/{arm}/cmdline').read_bytes()
  assert str(r).encode() in Path(f'/proc/{parent}/cmdline').read_bytes()
 except (OSError,AssertionError):
  records.append(dict(label=label,action='already progressed; untouched'));continue
 os.kill(parent,signal.SIGSTOP);os.kill(arm,signal.SIGSTOP)
 try:
  time.sleep(.05)
  if (r/'runs'/label/'run.json').exists() or Path(f'/proc/{arm}/task/{arm}/children').read_text().strip():
   records.append(dict(label=label,action='payload started; untouched'));continue
  cmd=Path(f'/proc/{arm}/cmdline').read_bytes().replace(b'\0',b' ').decode()
  os.kill(arm,signal.SIGTERM)
  target=r/'attempts'/'queued-before-fallback'/label
  target.parent.mkdir(parents=True,exist_ok=True)
  (r/'runs'/label).rename(target)
  records.append(dict(controller_pid=parent,arm_pid=arm,label=label,argv=cmd,action='terminate queued arm and resume controller with adaptive lanes',signal='SIGTERM',native_payload_started=False))
 finally:
  for pid in [arm,parent]:
   try: os.kill(pid,signal.SIGCONT)
   except ProcessLookupError: pass
(r/'queued-restart.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(records))
