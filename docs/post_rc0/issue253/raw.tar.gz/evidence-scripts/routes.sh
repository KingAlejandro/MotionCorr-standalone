#!/bin/bash
set -u
S=/mnt/clathrin/alex-motioncorr-253
export PATH=/home/alex/.mc-venv/bin:/usr/local/cuda-12.8/bin:$PATH
export CUDA_VISIBLE_DEVICES=GPU-b2cb2c39-8524-17fb-73a8-80cd61dbf83d CUDA_DEVICE_ORDER=PCI_BUS_ID OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1
export LD_LIBRARY_PATH=/usr/local/cuda-12.8/lib64:/home/alex/nvcomp53/nvcomp-linux-x86_64-5.3.0.16_cuda12-archive/lib
mkdir -p "$S/qf"
ln -s ../src-fix "$S/qf/src"
export QF_W="$S/qf"
for cfg in cuda nvcomp; do
 flock -n /tmp/motioncorr-bench.lock true || exit 90
 taskset -c 88-95 python3 "$S/src-fix/docs/rc0/qf/tools/run_compact_ingest_support_matrix.py" --binary "$S/build-fix-$cfg/motioncorr" --device "$CUDA_VISIBLE_DEVICES" --threads 8 --workdir "$S/qf/matrix-$cfg" --json "$S/qf/matrix-$cfg.json" > "$S/logs/matrix-$cfg.log" 2>&1
 echo $? > "$S/logs/matrix-$cfg.exit"
done
for cfg in cpu cuda nvcomp; do
 taskset -c 88-95 python3 "$S/src-fix/tools/validate_test_collection.py" --test-dir "$S/build-fix-$cfg" --dump-json "$S/logs/collection-$cfg.json" > "$S/logs/collection-$cfg.log" 2>&1
 echo $? > "$S/logs/collection-$cfg.exit"
done
cp "$S/src-fix/tests/cuda_hermitian_inverse.cpp" "$S/src-main/tests/"
# Rebuild the test-only overlay to make the baseline and fixed test bytes identical.
taskset -c 88-95 cmake --build "$S/build-main-cuda" -j8 --target cuda_hermitian_inverse > "$S/logs/rebuild-main-test.log" 2>&1 || exit $?
cp "$S/logs/inverse-main.log" "$S/logs/inverse-main-initial.log"
cp "$S/logs/inverse-main.exit" "$S/logs/inverse-main-initial.exit"
taskset -c 88-95 "$S/build-main-cuda/cuda_hermitian_inverse" > "$S/logs/inverse-main.log" 2>&1
echo $? > "$S/logs/inverse-main.exit"
echo done > "$S/routes-stage.done"
