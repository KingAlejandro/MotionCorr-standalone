#!/usr/bin/env bash
set -euo pipefail
R=/home/alex/mc-pr114-native-20260929
cd "$R"
exec 9>/tmp/motioncorr-gpu1-correctness.lock
flock -n 9
export PATH=/usr/local/cuda-12.8/bin:$PATH
export CUDA_VISIBLE_DEVICES=GPU-cd5b9f86-26e6-0a03-bdd2-effcfa0fe42d OMP_NUM_THREADS=1
nvidia-smi --query-compute-apps=gpu_uuid,pid,process_name --format=csv,noheader > occupancy-before.txt
if grep -q "$CUDA_VISIBLE_DEVICES" occupancy-before.txt; then echo 'Allocated GPU occupied'; exit 1; fi
{
 date -u; hostname; uname -a; uptime
 git -C src show -s --format='%H %T'; git -C main-src show -s --format='%H %T'
 sha256sum src/test-data/fixtures/synthetic_128x128_8frames.{mrcs,star}
 grep -E 'Cpus_allowed_list|Mems_allowed_list' /proc/$$/status
 cat /proc/$$/stat
 numactl --show
 nvidia-smi --query-gpu=index,uuid,driver_version --format=csv,noheader
} > provenance.txt
for arm in main candidate; do
 source_dir=src
 if [[ "$arm" = main ]]; then source_dir=main-src; fi
 (
  flock 8
  cmake -S "$source_dir" -B "build-$arm" -DCUDA=ON -DCMAKE_CUDA_ARCHITECTURES=80 -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON -DPython3_EXECUTABLE=/home/alex/mc-env/bin/python3 > "$arm-configure.log" 2>&1
  cmake --build "build-$arm" -j4 > "$arm-build.log" 2>&1
 ) 8>/tmp/motioncorr-vm-build.lock
 sha256sum "build-$arm/motioncorr" > "$arm-binary.sha256"
done
ctest --test-dir build-candidate --output-on-failure -j1 > ctest-candidate.log 2>&1
/home/alex/mc-env/bin/python3 driver.py > driver.log 2>&1
nvidia-smi --query-compute-apps=gpu_uuid,pid,process_name --format=csv,noheader > occupancy-after.txt
echo 'PASS native selected-frame recenter acceptance'
