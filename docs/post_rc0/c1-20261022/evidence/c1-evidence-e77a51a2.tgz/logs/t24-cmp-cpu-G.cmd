/home/alex/.mc-venv/bin/python3 /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/tools-v2-run/c1_tutorial24.py compare /t24/F-cpu-G/out /t24/c1-cpu-G/out F-cpu_vs_c1-cpu-G 
