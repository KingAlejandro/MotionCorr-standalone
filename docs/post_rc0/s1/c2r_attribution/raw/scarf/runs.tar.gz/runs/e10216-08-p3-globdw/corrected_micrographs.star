
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     0.517000   300.000000     2.700000     0.100000     0.517000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographName #1 
_rlnMicrographMetadata #2 
_rlnOpticsGroup #3 
_rlnAccumMotionTotal #4 
_rlnAccumMotionEarly #5 
_rlnAccumMotionLate #6 
/tmp/s13c-3646472/runs/e10216-08-p3-globdw/Movies/FoilHole_17063931_Data_14966722_14966723_20180617_1843_Fractions.mrc /tmp/s13c-3646472/runs/e10216-08-p3-globdw/Movies/FoilHole_17063931_Data_14966722_14966723_20180617_1843_Fractions.star            1   109.554451    64.725314    44.829137 
 
