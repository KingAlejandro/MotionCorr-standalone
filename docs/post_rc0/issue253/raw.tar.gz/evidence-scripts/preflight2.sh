#!/bin/bash
set -u
S=/mnt/clathrin/alex-motioncorr-253
export CUDA_VISIBLE_DEVICES=GPU-b2cb2c39-8524-17fb-73a8-80cd61dbf83d CUDA_DEVICE_ORDER=PCI_BUS_ID OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=1
export LD_LIBRARY_PATH=/usr/local/cuda-12.8/lib64:/home/alex/nvcomp53/nvcomp-linux-x86_64-5.3.0.16_cuda12-archive/lib
flock -n /tmp/motioncorr-bench.lock true || exit 90
taskset -c 88-95 cmake --build "$S/build-fix-nvcomp" -j1 --target cuda_dose_normalization > "$S/logs/preflight2-build.log" 2>&1 || exit $?
taskset -c 88-95 ctest --test-dir "$S/build-fix-nvcomp" -j1 -R '^(CudaDoseNormalization|CudaDoseSessionPlan)$' --output-on-failure --output-junit "$S/logs/preflight2.xml" > "$S/logs/preflight2.log" 2>&1
echo $? > "$S/logs/preflight2.exit"
