import fcntl, pathlib, time, os
p=pathlib.Path('/mnt/clathrin/alex-motioncorr-253')
locks=[]
for name,mode in [('/tmp/motioncorr-bench.lock',fcntl.LOCK_SH),('/tmp/motioncorr-gpu3-correctness.lock',fcntl.LOCK_EX)]:
 f=open(name,'a'); fcntl.flock(f,mode|fcntl.LOCK_NB); locks.append(f)
(p/'lease.ready').write_text(str(os.getpid()))
while not (p/'lease.stop').exists(): time.sleep(5)
