
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     0.970000   300.000000     2.700000     0.100000     0.970000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographName #1 
_rlnMicrographMetadata #2 
_rlnOpticsGroup #3 
_rlnAccumMotionTotal #4 
_rlnAccumMotionEarly #5 
_rlnAccumMotionLate #6 
/mnt/clathrin/alex-motioncorr-peakfit/runs/e12963-07-p3-cpuDC/Movies/FoilHole_4674858_Data_4659374_4659376_20230406_020623_EER.mrc /mnt/clathrin/alex-motioncorr-peakfit/runs/e12963-07-p3-cpuDC/Movies/FoilHole_4674858_Data_4659374_4659376_20230406_020623_EER.star            1    15.437761     1.731647    13.706113 
 
