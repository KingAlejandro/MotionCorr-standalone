// Test-only extraction from motioncorr_runner.cpp; upstream notices follow.
/***************************************************************************
 *
 * Author: "Sjors H.W. Scheres"
 * MRC Laboratory of Molecular Biology
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * This complete copyright notice must be included in any revised version of the
 * source code. Additional authorship citations may be added, but existing
 * author citations must be preserved.
 ***************************************************************************/
#include "src/motioncorr_runner.h"
#include "src/matrix2d.h"
ThirdOrderPolynomialModel fitBoundaryProductionAdapter(const std::vector<RFLOAT>& patch_frames, const std::vector<RFLOAT>& patch_xs, const std::vector<RFLOAT>& patch_ys, const std::vector<RFLOAT>& patch_xshifts, const std::vector<RFLOAT>& patch_yshifts, int nx, int ny, int& rank, RFLOAT& condition) {
const int n_obs = patch_frames.size(), n_params = 18;
		Matrix2D <RFLOAT> matA(n_obs, n_params);
		Matrix1D <RFLOAT> vecX(n_obs), vecY(n_obs), coeffX(n_params), coeffY(n_params);
		for (int i = 0; i < n_obs; i++) {
			VEC_ELEM(vecX, i) = patch_xshifts[i]; VEC_ELEM(vecY, i) = patch_yshifts[i];

			const RFLOAT x = patch_xs[i] / nx - 0.5;
			const RFLOAT y = patch_ys[i] / ny - 0.5;
			const RFLOAT z = patch_frames[i];
			const RFLOAT x2 = x * x, y2 = y * y, xy = x * y, z2 = z * z;
			const RFLOAT z3 = z2 * z;

			MAT_ELEM(matA, i, 0)  =      z;
			MAT_ELEM(matA, i, 1)  =      z2;
			MAT_ELEM(matA, i, 2)  =      z3;

			MAT_ELEM(matA, i, 3)  = x  * z;
			MAT_ELEM(matA, i, 4)  = x  * z2;
			MAT_ELEM(matA, i, 5)  = x  * z3;

			MAT_ELEM(matA, i, 6)  = x2 * z;
			MAT_ELEM(matA, i, 7)  = x2 * z2;
			MAT_ELEM(matA, i, 8)  = x2 * z3;

			MAT_ELEM(matA, i, 9)  = y  * z;
			MAT_ELEM(matA, i, 10) = y  * z2;
			MAT_ELEM(matA, i, 11) = y  * z3;

			MAT_ELEM(matA, i, 12) = y2 * z;
			MAT_ELEM(matA, i, 13) = y2 * z2;
			MAT_ELEM(matA, i, 14) = y2 * z3;

			MAT_ELEM(matA, i, 15) = xy * z;
			MAT_ELEM(matA, i, 16) = xy * z2;
			MAT_ELEM(matA, i, 17) = xy * z3;
		}

		const RFLOAT EPS = 1e-10;
		solve(matA, vecX, coeffX, EPS);
		solve(matA, vecY, coeffY, EPS);

Matrix2D<RFLOAT> u, v; Matrix1D<RFLOAT> w; svdcmp(matA, u, w, v);
RFLOAT lo = 1e30, hi = 0; rank = 0; for (int j=0; j<n_params; ++j) { if(w(j)>1e-10) ++rank; lo=std::min(lo,w(j)); hi=std::max(hi,w(j)); } condition=hi/lo;
ThirdOrderPolynomialModel model; model.coeffX=coeffX; model.coeffY=coeffY; return model; }
