
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     0.400000   300.000000     2.700000     0.100000     0.400000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographName #1 
_rlnMicrographMetadata #2 
_rlnOpticsGroup #3 
_rlnAccumMotionTotal #4 
_rlnAccumMotionEarly #5 
_rlnAccumMotionLate #6 
/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/c1-item12/runs/e10641-g4/out-ref_1db/Movies/HM70-1_10-A-002_0002_Oct28_23_00_41.mrc /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/c1-item12/runs/e10641-g4/out-ref_1db/Movies/HM70-1_10-A-002_0002_Oct28_23_00_41.star            1    83.696711    12.125721    71.570990 
/mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/c1-item12/runs/e10641-g4/out-ref_1db/Movies/HM70-1_10-A-004_0008_Oct28_23_06_04.mrc /mnt/clathrin/alex-motioncorr-c1-20261022-e77a51a220cb/c1-item12/runs/e10641-g4/out-ref_1db/Movies/HM70-1_10-A-004_0008_Oct28_23_06_04.star            1    63.769047     4.892873    58.876174 
 
