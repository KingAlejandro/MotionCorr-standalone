
# version 50001

data_optics

loop_ 
_rlnOpticsGroupName #1 
_rlnOpticsGroup #2 
_rlnMicrographOriginalPixelSize #3 
_rlnVoltage #4 
_rlnSphericalAberration #5 
_rlnAmplitudeContrast #6 
_rlnMicrographPixelSize #7 
opticsGroup1            1     1.640000   300.000000     2.700000     0.100000     1.640000 
 

# version 50001

data_micrographs

loop_ 
_rlnMicrographName #1 
_rlnMicrographMetadata #2 
_rlnOpticsGroup #3 
_rlnAccumMotionTotal #4 
_rlnAccumMotionEarly #5 
_rlnAccumMotionLate #6 
/mnt/clathrin/alex-motioncorr-s1/sweep/runs/e10474f4-00-p3-F-cpu/Movies/FoilHole_10919949_Data_10919593_10919595_20200711_001116_Fractions_mrc.mrc /mnt/clathrin/alex-motioncorr-s1/sweep/runs/e10474f4-00-p3-F-cpu/Movies/FoilHole_10919949_Data_10919593_10919595_20200711_001116_Fractions_mrc.star            1    31.212649     1.254286    29.958362 
 
